# Aqara M1S 192.168.0.100 - research read-only si decizii tehnice

Data investigatie initiala: 2026-08-28  
Hub: Aqara M1S Gen 1 `lumi.gateway.aeu01`  
IP de lucru: `192.168.0.100`  
Fisier brut pastrat integral: `AQARA_M1S_192_168_0_100_RESEARCH_RAW_2026-08-28.txt`

Acest document nu este procedura de instalare. Procedura de instalare ramane in `README_RO.md`, `README.md` si `README_FAST_RO.md`. Rolul acestui fisier este sa pastreze harta tehnica obtinuta din hub si motivul pentru care kitul curent foloseste `service_trim`, Factory Reset Guard si GPIO7 pentru buton.

Nu sunt incluse tokenuri MiIO, parole Wi-Fi, chei Zigbee sau credentiale MQTT.

---

## 1. Identitate hub

Observatii certe din investigatia initiala:

- nume: `Aqara-Hub-M1S-3CE4`;
- model firmware: `Aqara-Hub-M1S`;
- model intern: `lumi.gateway.aeu01`;
- product: `HM1S-G01`;
- firmware: `3.2.4`;
- MI firmware: `3.1.3`;
- hardware: `1.0`;
- vendor: Lumi United Technology / Aqara;
- IP investigat: `192.168.0.100`.

Interpretare:

- documentatia si kitul se aplica strict pentru Aqara M1S Gen 1 `lumi.gateway.aeu01`;
- alte modele trebuie validate separat inainte de flash sau boot custom.

---

## 2. Hardware, kernel si filesystem

Observatii certe:

- platforma/SoC: Realtek `RTL8197F`;
- CPU: MIPS 24Kc V8.5;
- kernel: Linux `3.10.90`;
- userland: BusyBox `v1.22.1`;
- toolchain observat: Realtek MSDK / gcc 4.9.4;
- RAM total: aproximativ 58 MB;
- root filesystem `/` este `squashfs` read-only;
- `/data` este `UBIFS` read-write si persistent;
- exista partitii MTD pentru bootloader, boot_info, factory, bbt, linux/rootfs A/B si data.

Consecinta pentru kit:

- nu modificam rootfs-ul;
- tot ce facem persistent se pune in `/data`;
- orice editare in `/data` trebuie tratata ca modificare reala, cu rollback clar.

---

## 3. Boot si ancora persistenta

Observatii certe:

- bootul standard ruleaza `/etc/init.d/rcS`;
- `rcS` monteaza `/proc`, `/var`, `/sys` si `/data`;
- `rcS` porneste servicii de baza, inclusiv property service si Wi-Fi;
- daca exista `/data/scripts/post_init.sh` executabil, acesta este pornit la boot.

Consecinta pentru kit:

- `/data/scripts/post_init.sh` este ancora persistenta principala;
- kitul curent instaleaza `post_init.sh` prin `hub_bundle/m1s_hub_bundle_LOCAL.tgz`;
- scriptul trebuie verificat cu `/bin/sh -n` inainte de reboot.

Decizie curenta:

- pastram `fw_manager.sh -r`, calea normala de pornire stock;
- nu folosim `fw_manager.sh -f -r`, care este calea de factory reset;
- pornim Factory Reset Guard inainte ca stackul stock sa primeasca inputul real.

---

## 4. Procese si servicii

Procese observate in investigatia initiala:

- `init`;
- `property_service`;
- `mdnsd`;
- `mosquitto -d`;
- `miio_agent`;
- `miio_client`;
- `mha_basis`;
- `mha_master -b`;
- `mijia_automation`;
- `homekitserver`;
- `wpa_supplicant`;
- `udhcpc`;
- `telnetd`;
- `syslogd`;
- scripturi custom de buton, Wi-Fi si tunel UART.

Observatii certe:

- `mha_basis` si `mha_master` sunt componente centrale;
- `homekitserver` este un proces mare, legat de HomeKit stock;
- `mijia_automation` este legat de automatizari Mi/Aqara;
- `mosquitto` exista local pe hub, dar pe loopback;
- bridge-ul de buton publica spre brokerul Home Assistant extern.

Ipoteze initiale:

- `homekitserver` si `mijia_automation` sunt probabil inutile pentru scopul proiectului cand hubul devine Router local;
- oprirea lor controlata poate reduce procesele active fara sa afecteze Zigbee Router, Wi-Fi, Telnet sau audio;
- `mha_basis` si `mha_master` nu trebuie oprite brutal.

Validare ulterioara inclusa in kit:

- `service_trim.sh` opreste controlat dupa boot `homekitserver` si `mijia_automation`;
- `service_trim` nu opreste `mha_basis` si `mha_master`;
- statusul asteptat dupa boot este in `/tmp/service_trim.status`.

---

## 5. Retea si porturi

Servicii observate:

- Telnet: port `23`;
- MQTT local hub: `127.0.0.1:1883`;
- MiIO local: `127.0.0.1:54322` si `54323`;
- tunel UART custom: port `1886`;
- portal Wi-Fi custom istoric: port `8080`;
- mDNS: UDP `5353`.

Porturi curente in kit:

- `23`: Telnet LAN-only;
- `1886`: tunel UART creat de integrarea Home Assistant la nevoie;
- `1888`: ISP temporar SPSDK, inchis dupa flash;
- `1889`: transfer temporar fisier/WAV de pe hub;
- `12345`: transfer manual temporar catre hub;
- `12346`: media player individual;
- `12347`: grup media si sursa WAV locala, conflict cunoscut;
- `12348`: sink PCM pentru WAV local;
- `12349`: upload WAV;
- `8080`: portal Wi-Fi recovery optional.

Concluzie:

- niciun port nu se publica in Internet;
- porturile temporare trebuie inchise dupa folosire;
- `1888` nu ramane deschis dupa flash.

---

## 6. Zigbee si JN5189

Observatii certe:

- cip Zigbee: NXP `JN5189`;
- UART Zigbee: `/dev/ttyS1`;
- baud: `115200`;
- reset JN5189: GPIO18;
- ISP JN5189: GPIO33;
- MQTT intern Zigbee stock: `zigbee/send` si `zigbee/recv` pe broker local;
- configuratii relevante gasite in `/etc/mzigbeeAgent.conf`, `/etc/zigbeeAgent.conf`, `/etc/zigbee_mqtt_config.json`, `/data/zigbee/*`.

Consecinta:

- nu publicam continutul brut din `/data/zigbee`;
- pentru Router custom tinem jos agentul Zigbee stock cand este necesar;
- Home Assistant/integratia trebuie sa administreze tunelul UART, fara `cat /dev/ttyS1` lasat manual.

Decizie curenta:

- firmware-ul curent este `jn5189_router_rgb_lux_rejoin_test.bin`;
- flash-ul se face pe Memory ID 0, zona aplicatiei;
- pentru hub stock se foloseste `JN5189-Flash-WRITE.ps1`;
- readbackul complet este verificare avansata separata, nu pas obligatoriu imediat dupa `FLASH_WRITE_OK`.

---

## 7. Buton fizic, reset si Factory Reset Guard

Observatii certe initiale:

- butonul fizic aparea ca `/dev/input/event0`;
- nume device: `lumi_key`;
- phys: `lumi_reset_key`;
- `mha_basis` tinea deschis `/dev/input/event0`;
- in binarele Aqara apar stringuri precum `basis.button`, `click`, `double_click`, `persist_click`, `hold`, `system_reset`, `system_factory_reset`, `system_reseting`;
- bridge-ul vechi `button_watch.sh` citea `/var/log/messages`, filtra `basis.button` si publica in MQTT.

Concluzie certa:

- bridge-ul vechi MQTT nu producea resetul;
- bridge-ul vechi doar copia/exporta catre Home Assistant un eveniment deja vazut de firmware-ul Aqara.

Ipoteza tehnica:

- resetul periculos era decis pe calea stock `event0 -> mha_basis/mha_master -> handler reset`;
- oprirea `button_watch.sh` nu putea opri resetul intern;
- oprirea `mha_basis` putea rupe functii centrale si nu era strategie acceptabila.

Decizie validata ulterior:

- nu oprim `mha_basis`;
- izolam `/dev/input/event0` fata de firmware-ul stock;
- Factory Reset Guard monteaza un director temporar peste `/dev/input`;
- creeaza un `/dev/input/event0` dummy char `1,3`;
- porneste stackul Aqara peste inputul izolat;
- butonul real este citit separat prin GPIO7;
- `gpio_button_watch.sh` publica evenimentele prin MQTT catre Home Assistant.

Calea curenta:

```text
buton fizic -> GPIO7 -> gpio_button_watch.sh -> m1s_mqtt_publish.sh -> MQTT HA
```

Calea stock izolata:

```text
/dev/input/event0 real -> ascuns de overlay -> mha_basis vede event0 dummy
```

Payloaduri curente:

```text
click
double_click
triple_click
quadruple_click
five_click
six_click
seven_click
eight_click
nine_click
ten_click
hold
hold_start
hold_repeat
hold_release
```

Validare asteptata:

- clickul fizic ajunge in MQTT si Home Assistant;
- cu guard activ nu apare click nou `basis.button` dupa apasare;
- statusul este in `/tmp/factory_reset_guard_boot.status` si `/tmp/gpio_button_watch.status`.

---

## 8. Audio si microfon

Observatii certe:

- ALSA este prezent;
- card audio: `rtl819xd_rt5680`;
- playback expus: `pcmC0D0p`;
- capture expus: `pcmC0D0c`;
- `/etc/asound.conf` configureaza conversii la 16000, 32000 si 48000 Hz;
- `arecord` exista ca link catre `/bin/aplay`;
- un test scurt de capture a putut deschide device-ul si crea WAV temporar in `/tmp`.

Incident:

- testul de capture audio a blocat temporar hubul;
- recovery a fost power-cycle fizic;
- nu s-a scris in flash/NVRAM, dar driverul sau stackul audio s-a putut bloca.

Ipoteze:

- capture audio poate proveni din driver generic Realtek sau codec RT5680 cu intrare nepopulata;
- M1S investigat probabil nu are microfon fizic montat;
- pot exista trasee/paduri nepopulate, dar nu exista dovada software ca un microfon este utilizabil direct.

Decizie:

- playback ramane suportat;
- audio input/microfon ramane pista separata, cu risc moderat;
- nu se repeta teste de capture pe huburi de lucru fara plan separat si acord explicit.

---

## 9. Ring light, indicator, alarma si lux

Modele stock gasite:

- `/etc/prop-model/light-model.json`;
- `/etc/prop-model/indicator-light-model.json`;
- `/etc/prop-model/illumination-sensor-model.json`;
- `/etc/prop-model/alarm-model.json`;
- `/etc/prop-model/arming-model.json`;
- `/etc/prop-model/play-spec-audio-model.json`.

Functii observate:

- ring light: on/off, brightness, color;
- indicator light: stare si interval efectiv;
- illumination sensor: citire si raportare;
- alarm: moduri armare, delay, durata, volum, sunete per mod, stop-preview;
- audio special: play-spec-audio, play-cycle, stop-play, audio-list, language-list.

Consecinta:

- hubul are functii stock utile pentru lumina/audio care merita pastrate;
- de aceea nu se opreste brutal `mha_basis` sau `mha_master`.

---

## 10. Fisiere custom importante

Observate in etapa initiala:

- `/data/scripts/post_init.sh`;
- `/data/m1s_button/button_watch.sh`;
- `/data/m1s_button/m1s_mqtt_publish.sh`;
- `/data/scripts/mqtt_tunnel.sh`;
- `/data/scripts/audio_cleanup.sh`;
- `/data/m1s_wifi/*`.

Curent in kit:

- `/data/scripts/post_init.sh`;
- `/data/scripts/service_trim.sh`;
- `/data/scripts/service_trim.conf`;
- `/data/scripts/factory_reset_guard_boot.sh`;
- `/data/scripts/factory_reset_guard_boot.conf`;
- `/data/scripts/gpio_button_watch.sh`;
- `/data/scripts/gpio_button_watch.conf`;
- `/data/scripts/jn5189_enter_isp_1888.sh`;
- `/data/scripts/jn5189_close_isp_1888.sh`;
- `/data/scripts/jn5189_boot_router.sh`;
- `/data/m1s_button/m1s_mqtt_publish.sh`;
- `/data/m1s_button/m1s_button.conf`.

Nota:

- vechile backupuri locale de pe hub sunt utile pentru audit, dar nu trebuie transformate in sursa de adevar pentru kit;
- sursa de adevar curenta este arhiva kitului si hashurile ei.

---

## 11. Ce nu se face fara acord explicit

Pentru research read-only sau diagnostic:

- nu se da `kill`/restart la procese;
- nu se da reboot/reset/poweroff;
- nu se scrie in `/data`;
- nu se scrie in `/sys/class/gpio`;
- nu se scrie in `/dev/ttyS1`;
- nu se ruleaza `fw_manager` cu optiuni de reset;
- nu se publica MQTT catre hub pentru comenzi de stare;
- nu se repeta teste audio capture;
- nu se modifica `post_init.sh`;
- nu se sterg backupuri;
- nu se activeaza/dezactiveaza servicii.

Pentru instalarea kitului, aceste actiuni devin permise numai in pasii documentati din README si cu hubul corect identificat.

---

## 12. Cum a influentat researchul kitul curent

Researchul a dus la urmatoarele decizii tehnice:

1. `mha_basis` si `mha_master` se pastreaza.
2. `homekitserver` si `mijia_automation` se opresc controlat dupa boot prin `service_trim`.
3. Calea stock a butonului se izoleaza prin Factory Reset Guard, nu prin kill de procese.
4. Butonul real se citeste separat pe GPIO7.
5. MQTT ramane topicul cunoscut de Home Assistant: `m1s/<ultimul_octet_IP>/button/action`.
6. Firmware-ul JN5189 se scrie prin flux rapid cu backup A/B inainte si `FLASH_WRITE_OK` ca validare de scriere.
7. Readbackul complet ramane optional deoarece SPSDK poate pierde handshake-ul dupa write.
8. Audio capture/microfon ramane cercetare separata, nu functie inclusa in kit.

---

## 13. Lucruri nerezolvate / de pastrat in backlog

- conflictul portului `12347` intre media group si sursa WAV locala;
- verificarea hardware a traseului de microfon sau a padurilor nepopulate;
- separarea finala a codului legacy MQTT/select din integrare;
- securizarea suplimentara a serviciului Home Assistant `run_command`;
- clarificarea unui eventual proces real „device library”, daca apare pe un hub sau firmware concret;
- validarea extinsa a `hold_start`, `hold_repeat`, `hold_release` pe toate huburile;
- comportamentul la log rotation pentru watcherul legacy, daca mai ramane pastrat.

---

## 14. Referinte in kit

- Procedura detaliata: `README_RO.md`
- Procedura rapida: `README_FAST_RO.md`
- Procedura engleza scurta: `README.md`
- Raport brut integral: `docs/research/AQARA_M1S_192_168_0_100_RESEARCH_RAW_2026-08-28.txt`
- Acest sumar tehnic: `docs/research/AQARA_M1S_192_168_0_100_RESEARCH_READ_ONLY_2026-08-28.md`
