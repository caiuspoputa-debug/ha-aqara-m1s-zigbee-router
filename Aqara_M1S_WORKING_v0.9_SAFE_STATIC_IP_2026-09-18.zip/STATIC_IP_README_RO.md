# Manager IPv4 sigur pentru Aqara M1S - bundle v0.9

Acest bundle adaugă `/data/m1s_network/network_manager.sh` fără să modifice `fw_manager.sh`.

## Reguli

- Wi-Fi-ul stock se conectează primul, prin DHCP.
- Modul static este limitat la rețeaua `/24` curentă; se schimbă numai ultimul număr, între 2 și 254.
- Adresa candidat este adăugată temporar, fără oprirea adresei curente.
- Home Assistant trebuie să se conecteze la candidat, să citească MAC-ul Wi-Fi și să confirme același hub.
- Fără confirmare, candidatul este eliminat automat după 120 de secunde.
- După confirmare, configurația este salvată în `/data/m1s_network/network.conf` și reaplicată la boot.
- La schimbarea SSID-ului, configurația statică este ștearsă înainte de pornirea modulului Wi-Fi recovery, astfel încât noua rețea să pornească prin DHCP.
- Topic-ul MQTT al butonului este memorat la instalare și nu se schimbă odată cu IP-ul.

## Verificare înainte de primul test

Instalează întâi bundle-ul pe un singur hub și repornește controlat. Din Telnet:

```sh
/data/m1s_network/network_manager.sh status
```

Răspunsul trebuie să conțină `protocol=1`, `mode=dhcp`, IP-ul curent, gateway-ul, MAC-ul și `button_topic_id`. Nu edita manual `network.conf`; folosește integrarea Home Assistant v0.21.0.

Pentru recuperare locală, comanda următoare salvează DHCP și pornește reînnoirea după trimiterea confirmării:

```sh
/data/m1s_network/network_manager.sh dhcp
```

Testează pe primul hub: schimbare DHCP -> static, reboot, buton MQTT, revenire DHCP și schimbare Wi-Fi. Extinde instalarea numai după aceste verificări.
