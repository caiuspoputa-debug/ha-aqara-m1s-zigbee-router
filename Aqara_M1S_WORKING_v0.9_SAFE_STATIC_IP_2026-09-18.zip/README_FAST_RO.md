# Aqara M1S v0.8 STRICT10 HOLD EVENTS — flux rapid stock -> Router + player + buton protejat

Validat practic pe huburile `.114` si `.115` in 10-11 august 2026.
Factory Reset Guard a fost validat pe hubul de lucru `192.168.0.100` in 1 septembrie 2026.
Acest kit LOCAL foloseste configuratia MQTT din:

```text
/data/m1s_button/m1s_button.conf
```

Nu publica tokenul MiIO, parola Wi-Fi sau credentialele MQTT. Topic buton: automat `m1s/<ultimul_octet_IP>/button/action`.

## Ce este nou in v0.8

- Factory Reset Guard persistent, reversibil:
  - izoleaza `/dev/input/event0` prin overlay peste `/dev/input`;
  - `mha_basis` vede un `event0` dummy, nu butonul real;
  - butonul real este citit prin GPIO7;
  - evenimentul este publicat in MQTT pe topicul existent.
- Service trim:
  - opreste dupa boot `homekitserver`;
  - opreste dupa boot `mijia_automation`;
  - lasa `mha_basis`, `mha_master`, telnet, Wi-Fi si JN5189 active.
- Rollback rapid:
  - in Telnet: editeaza `/data/scripts/factory_reset_guard_boot.conf`;
  - seteaza `ENABLE_FACTORY_RESET_BOOT_GUARD=0`;
  - reboot/power-cycle.
- Research arhivat separat:
  - `docs/research/AQARA_M1S_192_168_0_100_RESEARCH_READ_ONLY_2026-08-28.md`;
  - `docs/research/AQARA_M1S_192_168_0_100_RESEARCH_RAW_2026-08-28.txt`.

## REGULA DE PROMPT

- `PS C:\...>` = **POWERSHELL pe Windows**
- `#` = **TELNET pe hub**

Nu lipi comenzile `/data/...` in PowerShell si nu lipi comenzile `C:\Windows\py.exe` in Telnet.

## 0. Hub stock

1. Adauga hubul in Xiaomi Home, Wi-Fi 2.4 GHz.
2. Rezerva IP-ul in DHCP.
3. Obtine tokenul MiIO.

## 1. Activeaza Telnet — POWERSHELL `PS>`

Pentru firmware stock compatibil, secventa fizica documentata de activare Telnet este:

```text
5-2-2-2-2-2-2
```

Comanda MiIO de mai jos se ruleaza din PowerShell, nu din Telnet. Daca Telnet nu este deja activ, nu exista prompt `#` si nu poti rula comenzi pe hub pana cand Telnetul nu raspunde.

Din radacina kitului:

```powershell
.\scripts\windows\Enable-Telnet.ps1 -HubIp HUB_IP
```

Apoi:

```powershell
telnet HUB_IP
```

Login: `admin`, parola goala.

## 2. Transfer bundle — TELNET `#`

```sh
rm -f /tmp/m1s_hub_bundle_LOCAL.tgz
nc -l -p 12345 > /tmp/m1s_hub_bundle_LOCAL.tgz
```

### POWERSHELL `PS>`

```powershell
.\scripts\windows\Send-FileToM1S.ps1 -HubIp HUB_IP -Path .\hub_bundle\m1s_hub_bundle_LOCAL.tgz -Port 12345
```

### TELNET `#`

```sh
rm -rf /tmp/m1s_bundle
mkdir -p /tmp/m1s_bundle
cd /tmp/m1s_bundle
tar -xzf /tmp/m1s_hub_bundle_LOCAL.tgz
chmod 700 install.sh
./install.sh
```

Asteptat:

```text
M1S_BUNDLE_V0_8_INSTALLED
Factory Reset Guard este inclus si configurabil in /data/scripts/factory_reset_guard_boot.conf.
Verifica setarile, apoi reboot controlat.
```

## 3. Intra o singura data in ISP — TELNET `#`

```sh
/data/scripts/jn5189_enter_isp_1888.sh
```

Asteptat:

```text
ISP_LISTENER_OK port=1888 ...
GPIO33=0 GPIO18=0
```

**Nu rerula `enter_isp` in timp ce ruleaza o comanda SPSDK pe Windows.**

Daca trebuie resetata etapa ISP dupa o eroare SPSDK:

```sh
/data/scripts/jn5189_close_isp_1888.sh
/data/scripts/jn5189_enter_isp_1888.sh
```

Apoi nu mai atinge Telnetul pana termina comanda Windows.

## 4. Doua backupuri + comparatie — POWERSHELL `PS>`

Un singur script face secventa validata: `info -> read A -> read B -> SHA256 compare`.

```powershell
.\scripts\windows\JN5189-Backup-PAIR-VERIFY.ps1 -HubIp HUB_IP
```

Asteptat la final:

```text
BACKUP_PAIR_OK SHA256=...
```

Fiecare backup trebuie sa aiba exact `646656` bytes. Daca hashurile difera, STOP.

## 5. Flash — POWERSHELL `PS>`

```powershell
.\scripts\windows\JN5189-Flash-WRITE.ps1 -HubIp HUB_IP -FirmwarePath .\firmware\jn5189_router_rgb_lux_rejoin_test.bin
```

Asteptat:

```text
FLASH_WRITE_OK bytes=209296 SHA256=A1A1F302BE9E3AB95FD6A3B8F4AC260E1F397FEC275FB3E3CAF8418CD75E7A2F
```

Nu facem readback imediat dupa write; SPSDK 3.10 a pierdut handshake-ul pe hub valid desi firmware-ul a pornit corect.

## 6. Inchide ISP + boot Router — TELNET `#`

```sh
/data/scripts/jn5189_close_isp_1888.sh
/data/scripts/jn5189_boot_router.sh
```

Asteptat:

```text
ISP_LISTENER_CLOSED port=1888
ROUTER_BOOT_SENT GPIO33=1 GPIO18=0
```

Activeaza Permit Join in Zigbee2MQTT si asteapta ca routerul sa intre.

## 7. Adauga hubul in integrarea Home Assistant

In Home Assistant adauga IP-ul nou in integrarea **Aqara M1S Local** si confirma ca media playerul apare/raspunde.

**Integrarea se face inainte de rebootul final.**

## 8. Reboot final — TELNET `#`

```sh
sync
reboot
```

Dupa revenire, `post_init.sh` porneste persistent:

- Telnet;
- syslogd;
- Factory Reset Guard, daca este activ;
- GPIO button watcher pentru MQTT;
- `mha_master -b`;
- JN5189 Router;
- service trim pentru HomeKit/Mijia.

## 9. Validare finala — numai doua probe

1. Playerul functioneaza.
2. Un click fizic ajunge la `m1s/<ultimul_octet>/button/action`, iar hubul ramane online.
3. Optional in Telnet, verifica:

```sh
cat /tmp/factory_reset_guard_boot.status
cat /tmp/gpio_button_watch.status
mount | grep /dev/input
tail -20 /tmp/gpio_button_watch.log
grep -n -e 'basis.button' /var/log/messages | tail
```

Asteptat cu guard activ:

- `phase=fw_manager_after_isolation`;
- `one_shot=0`;
- `run_seconds=0`;
- `ramfs on /dev/input`;
- `/dev/input/event0` este dummy `1,3`;
- `gpio_button_watch.log` arata `published action=click rc=0`;
- nu apare `basis.button click` dupa apasare.

Daca ambele merg: **HUB GATA**.

## Configurare rapida pe huburi existente/noi

Setarile principale sunt in:

```sh
/data/scripts/factory_reset_guard_boot.conf
/data/scripts/service_trim.conf
/data/scripts/gpio_button_watch.conf
/data/m1s_button/m1s_button.conf
```

Implicit v0.8 instaleaza guardul persistent activ:

```sh
ENABLE_FACTORY_RESET_BOOT_GUARD=1
MODE=input_dir_overlay
ONE_SHOT=0
GPIO_WATCH_SECONDS=0
```

Pentru test one-shot pe un hub nou, inainte de reboot:

```sh
sed -i 's/^ONE_SHOT=.*/ONE_SHOT=1/' /data/scripts/factory_reset_guard_boot.conf
sed -i 's/^ENABLE_FACTORY_RESET_BOOT_GUARD=.*/ENABLE_FACTORY_RESET_BOOT_GUARD=1/' /data/scripts/factory_reset_guard_boot.conf
sync
reboot
```

Pentru dezactivare completa:

```sh
sed -i 's/^ENABLE_FACTORY_RESET_BOOT_GUARD=.*/ENABLE_FACTORY_RESET_BOOT_GUARD=0/' /data/scripts/factory_reset_guard_boot.conf
sync
reboot
```

## Ce a fost reparat fata de v0.5.7/v0.6

- installerul nu mai moare la `setprop` cu return code nenul;
- ZIP-ul este flat: nu mai contine folder identic inca o data in interior;
- backupul face automat `dk6prog info` inainte de prima citire;
- backupul face A + B + SHA256 compare intr-o singura comanda;
- flash script foloseste direct argumentele SPSDK, fara wrapperul PowerShell care le reordona;
- hashul firmware este corect (`...3CAF8418...`, fara `C` in plus);
- fara readback imediat dupa write;
- publisher MQTT simplu/sincron, fara `nc & -> sleep -> kill`, care a blocat hubul dupa click;
- calea legacy pe syslog ramane doar diagnostic/optiune veche;
- butonul curent foloseste GPIO7 + MQTT prin Factory Reset Guard, nu `/dev/input/event0`;
- nu folosim `grep -E` pe BusyBox;
- integrarea HA este pusa explicit inainte de rebootul final.
- v0.8 adauga Factory Reset Guard persistent si GPIO7 -> MQTT, ca butonul sa nu mai ajunga la logica firmware de reset.
- v0.8 adauga service_trim pentru `homekitserver` si `mijia_automation`.


## Button events strict10 + hold-events

GPIO watcher publica numai evenimente controlate: click, double_click, triple_click, quadruple_click, five_click, six_click, seven_click, eight_click, nine_click, ten_click. Secventele peste 10 apasari sunt ignorate si apar doar in log. Apasarea lunga publica hold_start, hold_repeat si hold_release. HOLD_REPEAT_TENTHS=5 controleaza repetarea la aproximativ 0.5 secunde.
