[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$HubIp,
    [Parameter(Mandatory=$true)][string]$FirmwarePath,
    [int]$Port=1888,
    [string]$Python='C:\Windows\py.exe'
)

$ErrorActionPreference='Stop'
$ExpectedBytes=209296
$ExpectedHash='A1A1F302BE9E3AB95FD6A3B8F4AC260E1F397FEC275FB3E3CAF8418CD75E7A2F'

$fw=Get-Item -LiteralPath $FirmwarePath
if ($fw.Length -ne $ExpectedBytes) { throw "Firmware size invalid: $($fw.Length), expected $ExpectedBytes" }
$hash=(Get-FileHash -LiteralPath $fw.FullName -Algorithm SHA256).Hash
if ($hash -ne $ExpectedHash) { throw "Firmware SHA256 invalid: $hash" }

Write-Host '1/2 ERASE application region 0x0..0x33200'
& $Python -3 -m spsdk.apps.dk6prog -b PYSERIAL -d "socket://${HubIp}:$Port" -n erase 0x0 0x33200 0
if ($LASTEXITCODE -ne 0) { throw "ERASE failed: $LASTEXITCODE" }

Start-Sleep -Seconds 2

Write-Host '2/2 WRITE firmware (209296 bytes)'
& $Python -3 -m spsdk.apps.dk6prog -b PYSERIAL -d "socket://${HubIp}:$Port" -n write 0x0 $fw.FullName 0
if ($LASTEXITCODE -ne 0) { throw "WRITE failed: $LASTEXITCODE" }

Write-Host "FLASH_WRITE_OK bytes=$ExpectedBytes SHA256=$hash"
Write-Host 'Next on TELNET: close ISP, boot router, join Zigbee2MQTT. Do not run immediate readback.'
