# Aqara M1S 0.10.0 STABLE ULTIMATE KIT

Kit unic pentru pregatirea si conversia unui Aqara M1S Gen 1 `lumi.gateway.aeu01`.

**Incepe cu:** `START_AICI_RO.md`

Componente principale:
- `installers/m1s_ultimate_hub_prep_v0.10.0.tgz` - installer unic pentru partea Linux a hubului;
- `scripts/windows/JN5189-Backup-PAIR-VERIFY.ps1` - backup dublu cu verificare;
- `scripts/windows/JN5189-Flash-WRITE.ps1` - flash blocat de backup gate;
- `scripts/hub/ultimate_preflash_check.sh` - poarta stricta inainte de flash;
- `scripts/hub/verify_hub_ultimate.sh` - verificare dupa reboot;
- `home_assistant/ha-aqara-m1s-zigbee-router-v0.21.7-SNAPSHOT.zip` - snapshot exact HA v0.21.7;
- `SHA256SUMS.txt` - integritatea tuturor fisierelor kitului.

Acesta este un kit personal/local. Nu il publica nesanitizat.
