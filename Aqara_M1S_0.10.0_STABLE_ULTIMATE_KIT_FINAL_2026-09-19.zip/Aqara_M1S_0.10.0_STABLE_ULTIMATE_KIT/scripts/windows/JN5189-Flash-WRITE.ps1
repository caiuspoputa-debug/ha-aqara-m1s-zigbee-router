[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$HubIp,
    [string]$FirmwarePath=(Join-Path $PSScriptRoot '..\..\firmware\jn5189_router_rgb_lux_rejoin_test.bin'),
    [string]$BackupMarker=(Join-Path (Join-Path $PWD 'backups') "BACKUP_PAIR_OK_${HubIp}.txt"),
    [int]$Port=1888,
    [string]$Python='C:\Windows\py.exe'
)

$ErrorActionPreference='Stop'
$ExpectedBytes=209296
$ExpectedHash='A1A1F302BE9E3AB95FD6A3B8F4AC260E1F397FEC275FB3E3CAF8418CD75E7A2F'
$ExpectedBackupBytes=646656

function Invoke-Dk6Prog {
    param([string[]]$DkArgs,[string]$Step)
    $leaf=[IO.Path]::GetFileName($Python).ToLowerInvariant()
    if ($leaf -eq 'py.exe' -or $leaf -eq 'py') {
        & $Python -3 -m spsdk.apps.dk6prog @DkArgs
    }
    else {
        & $Python -m spsdk.apps.dk6prog @DkArgs
    }
    if ($LASTEXITCODE -ne 0) { throw "$Step failed with exit code $LASTEXITCODE" }
}

if (-not (Test-Path -LiteralPath $Python) -and -not (Get-Command $Python -ErrorAction SilentlyContinue)) {
    throw "Python launcher not found: $Python"
}

# Hard safety gate: this kit will not erase/write JN5189 until the current flow
# has produced two identical full-flash backups for this hub.
if (-not (Test-Path -LiteralPath $BackupMarker -PathType Leaf)) {
    throw "BACKUP_GATE_MISSING: $BackupMarker. Run JN5189-Backup-PAIR-VERIFY.ps1 first."
}
$gate=@{}
Get-Content -LiteralPath $BackupMarker -Encoding ASCII | ForEach-Object {
    if ($_ -match '^([^=]+)=(.*)$') { $gate[$matches[1]]=$matches[2] }
}
if ($gate['HubIp'] -ne $HubIp) { throw "BACKUP_GATE_WRONG_HUB: marker=$($gate['HubIp']) requested=$HubIp" }
if ([int64]$gate['Bytes'] -ne $ExpectedBackupBytes) { throw 'BACKUP_GATE_BAD_SIZE' }
if ([string]::IsNullOrWhiteSpace($gate['FileA']) -or [string]::IsNullOrWhiteSpace($gate['FileB'])) { throw 'BACKUP_GATE_FILES_MISSING' }
foreach ($path in @($gate['FileA'],$gate['FileB'])) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "BACKUP_FILE_MISSING: $path" }
    $item=Get-Item -LiteralPath $path
    if ($item.Length -ne $ExpectedBackupBytes) { throw "BACKUP_FILE_BAD_SIZE: $path" }
    $h=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    if ($h -ne $gate['SHA256']) { throw "BACKUP_FILE_HASH_CHANGED: $path" }
}
Write-Host "BACKUP_GATE_OK SHA256=$($gate['SHA256'])"

$fw=Get-Item -LiteralPath $FirmwarePath
if ($fw.Length -ne $ExpectedBytes) { throw "Firmware size invalid: $($fw.Length), expected $ExpectedBytes" }
$hash=(Get-FileHash -LiteralPath $fw.FullName -Algorithm SHA256).Hash
if ($hash -ne $ExpectedHash) { throw "Firmware SHA256 invalid: $hash" }
Write-Host "FIRMWARE_OK bytes=$($fw.Length) SHA256=$hash"

Write-Host '1/2 ERASE application region 0x0..0x33200'
Invoke-Dk6Prog -Step 'ERASE' -DkArgs @('-b','PYSERIAL','-d',"socket://${HubIp}:$Port",'-n','erase','0x0','0x33200','0')
Start-Sleep -Seconds 2

Write-Host '2/2 WRITE firmware (209296 bytes)'
Invoke-Dk6Prog -Step 'WRITE' -DkArgs @('-b','PYSERIAL','-d',"socket://${HubIp}:$Port",'-n','write','0x0',$fw.FullName,'0')

Write-Host "FLASH_WRITE_OK bytes=$ExpectedBytes SHA256=$hash"
Write-Host 'Next on TELNET: close ISP, boot router, join Zigbee2MQTT. Do not run immediate readback.'
