[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$HubIp,
    [string]$OutputDirectory=(Join-Path $PWD 'backups'),
    [int]$Port=1888,
    [string]$Python='C:\Windows\py.exe'
)

$ErrorActionPreference='Stop'
$ExpectedBytes=646656

function Invoke-Dk6Prog {
    param([string[]]$DkArgs,[string]$Step)
    $leaf=[IO.Path]::GetFileName($Python).ToLowerInvariant()
    if ($leaf -eq 'py.exe' -or $leaf -eq 'py') {
        & $Python -3 -m spsdk.apps.dk6prog @DkArgs
    }
    else {
        & $Python -m spsdk.apps.dk6prog @DkArgs
    }
    if ($LASTEXITCODE -ne 0) {
        throw "$Step failed with exit code $LASTEXITCODE. Re-arm ISP on the hub once, then rerun this script."
    }
}

if (-not (Test-Path -LiteralPath $Python) -and -not (Get-Command $Python -ErrorAction SilentlyContinue)) {
    throw "Python launcher not found: $Python"
}

New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null

$stampA=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$fileA=Join-Path $OutputDirectory "jn5189_original_flash_${HubIp}_${stampA}_A.bin"
Write-Host '1/3 Read backup A (646656 bytes)...'
Invoke-Dk6Prog -Step 'backup A' -DkArgs @(
    '-b','PYSERIAL',
    '-d',"socket://${HubIp}:$Port",
    '-n','read','-o',$fileA,
    '0x0',"$ExpectedBytes",'0'
)

Start-Sleep -Seconds 2

$stampB=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$fileB=Join-Path $OutputDirectory "jn5189_original_flash_${HubIp}_${stampB}_B.bin"
Write-Host '2/3 Read backup B (646656 bytes)...'
Invoke-Dk6Prog -Step 'backup B' -DkArgs @(
    '-b','PYSERIAL',
    '-d',"socket://${HubIp}:$Port",
    '-n','read','-o',$fileB,
    '0x0',"$ExpectedBytes",'0'
)

$a=Get-Item -LiteralPath $fileA
$b=Get-Item -LiteralPath $fileB
if ($a.Length -ne $ExpectedBytes) { throw "Backup A incomplete: $($a.Length) bytes" }
if ($b.Length -ne $ExpectedBytes) { throw "Backup B incomplete: $($b.Length) bytes" }

$hashA=(Get-FileHash -LiteralPath $a.FullName -Algorithm SHA256).Hash
$hashB=(Get-FileHash -LiteralPath $b.FullName -Algorithm SHA256).Hash

Write-Host '3/3 Compare backups...'
[pscustomobject]@{Copy='A';File=$a.FullName;Bytes=$a.Length;SHA256=$hashA}
[pscustomobject]@{Copy='B';File=$b.FullName;Bytes=$b.Length;SHA256=$hashB}

if ($hashA -ne $hashB) {
    throw "BACKUP_HASH_MISMATCH: A=$hashA B=$hashB. STOP; do not flash."
}

$marker=Join-Path $OutputDirectory "BACKUP_PAIR_OK_${HubIp}.txt"
@(
    "HubIp=$HubIp"
    "Port=$Port"
    "Bytes=$ExpectedBytes"
    "SHA256=$hashA"
    "FileA=$($a.FullName)"
    "FileB=$($b.FullName)"
    "Created=$((Get-Date).ToString('o'))"
) | Set-Content -LiteralPath $marker -Encoding ASCII

Write-Host "BACKUP_PAIR_OK SHA256=$hashA"
Write-Host "BACKUP_GATE=$marker"
