[CmdletBinding()]
param([string]$Python = 'C:\Windows\py.exe')
$ErrorActionPreference = 'Stop'

function Invoke-Py {
    param([string[]]$Args)
    $leaf=[IO.Path]::GetFileName($Python).ToLowerInvariant()
    if($leaf -eq 'py.exe' -or $leaf -eq 'py'){ & $Python -3 @Args } else { & $Python @Args }
    if($LASTEXITCODE -ne 0){ throw "Python check failed: $($Args -join ' ')" }
}

if (-not (Test-Path -LiteralPath $Python) -and -not (Get-Command $Python -ErrorAction SilentlyContinue)) {
    throw "Python launcher not found: $Python"
}
Write-Host 'Python:'; Invoke-Py @('--version')
Write-Host 'python-miio:'; Invoke-Py @('-c','import miio; print("python-miio OK")')
Write-Host 'SPSDK dk6prog:'; Invoke-Py @('-m','spsdk.apps.dk6prog','--help')
if (Get-Command telnet.exe -ErrorAction SilentlyContinue) {
    Write-Host 'Windows Telnet Client: OK'
}
else {
    Write-Warning 'telnet.exe nu este instalat. Poti folosi PuTTY/Telnet sau activa Windows Telnet Client.'
}
Write-Host 'PREREQUISITES_OK'
