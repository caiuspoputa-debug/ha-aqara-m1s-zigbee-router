#!/bin/sh
# Verificare non-distructiva inainte de backup/programare JN5189.
# Ruleaza prin Telnet pe Aqara M1S Gen 1.

PORT="${1:-1888}"

echo "=== MODEL / SISTEM ==="
getprop ro.product.model 2>/dev/null || true
uname -a
busybox 2>/dev/null | head -n 1 || true

echo "=== RETEA ==="
ifconfig wlan0 2>/dev/null || true

echo "=== SELECTIE STOCK WI-FI STA/AP (FARA CREDENTIALE) ==="
cloud_provisioned="$(getprop persist.app.cloud_provisioned 2>/dev/null)"
hap_provisioned="$(getprop persist.app.hap_provisioned 2>/dev/null)"
hap_keepalive="$(getprop persist.app.hap_keepalive 2>/dev/null)"
user_paired="$(getprop persist.app.user_paired 2>/dev/null)"
echo "cloud_provisioned=$cloud_provisioned"
echo "hap_provisioned=$hap_provisioned"
echo "hap_keepalive=$hap_keepalive"
echo "user_paired=$user_paired"
if [ "$cloud_provisioned" != "true" ] && \
   [ "$hap_provisioned" != "true" ] && \
   [ "$hap_keepalive" != "true" ]; then
    echo "ATENTIE: AP_RISK - fw_manager.sh poate selecta AP la urmatorul boot."
else
    echo "STA_EXPECTED - cel putin o stare de provisioning este true."
fi

echo "=== PROCESE CARE POT OCUPA UART ==="
ps w 2>/dev/null | grep -e '[m]zigbee_agent' -e '[a]pp_monitor' -e '[c]at /dev/ttyS1' -e '[n]c -l -p 1886' -e '[n]c -l -p 1888' || true

echo "=== LISTENERS RELEVANTI ==="
netstat -lnt 2>/dev/null | grep -e ":23 " -e ":1886 " -e ":$PORT " -e ":12346 " -e ":12347 " -e ":12348 " -e ":12349 " -e ":8080 " || true

echo "=== GPIO ==="
for gpio in 18 33; do
    printf 'gpio%s direction=' "$gpio"
    cat "/sys/class/gpio/gpio${gpio}/direction" 2>/dev/null || echo "N/A"
    printf 'gpio%s value=' "$gpio"
    cat "/sys/class/gpio/gpio${gpio}/value" 2>/dev/null || echo "N/A"
done

echo "=== SPATIU /DATA ==="
df -h /data 2>/dev/null || df /data 2>/dev/null || true

echo "=== REZULTAT ==="
if ps w 2>/dev/null | grep '[c]at /dev/ttyS1' >/dev/null 2>&1; then
    echo "STOP: exista cat /dev/ttyS1. Dezactiveaza integrarea HA si elibereaza UART-ul."
    exit 2
fi
if ps w 2>/dev/null | grep "[n]c -l -p $PORT" >/dev/null 2>&1; then
    echo "ATENTIE: exista deja un listener pe portul $PORT."
fi
echo "PREFLIGHT_OK: scriptul nu a modificat hubul."
