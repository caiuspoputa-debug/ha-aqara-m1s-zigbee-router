#!/bin/sh
# Aqara M1S v0.10.0 Stable Ultimate - post-reboot verification.
# Non-destructive; never prints Wi-Fi/MQTT credentials.

EXPECTED_MANAGER_MD5='186d81b3f459c43463d25103cda835ac'
FAIL=0
ok() { echo "OK: $*"; }
warn() { echo "WARN: $*"; }
bad() { echo "FAIL: $*"; FAIL=1; }

get_ip() { ifconfig wlan0 2>/dev/null | sed -n 's/.*inet addr:\([^ ]*\).*/\1/p' | head -n 1; }

wait_process()
{
  pattern="$1"
  max_seconds="${2:-90}"
  waited=0
  while [ "$waited" -lt "$max_seconds" ]; do
    ps w 2>/dev/null | grep "$pattern" >/dev/null 2>&1 && return 0
    sleep 2
    waited=$((waited + 2))
  done
  return 1
}

echo '=== IDENTITY ==='
echo "date=$(date)"
echo "model=$(getprop ro.product.model 2>/dev/null)"
echo "ip=$(get_ip)"

[ "$(getprop ro.product.model 2>/dev/null)" = 'lumi.gateway.aeu01' ] && ok 'target model' || bad 'unexpected model'

if [ -x /data/m1s_network/network_manager.sh ]; then
  MGR_MD5="$(md5sum /data/m1s_network/network_manager.sh 2>/dev/null | awk '{print $1}')"
  [ "$MGR_MD5" = "$EXPECTED_MANAGER_MD5" ] && ok "network manager fixed md5=$MGR_MD5" || bad "network manager md5 mismatch=$MGR_MD5"
  /data/m1s_network/network_manager.sh status 2>/dev/null || bad 'network manager status failed'
else
  bad 'network manager missing'
fi

echo '=== WAIT FOR BOOT SERVICES ==='
for pattern in '[t]elnetd' '[s]yslogd' '[w]ifi_manager.sh' '[m]1s_wifi_portal_safe.sh' '[g]pio_button_watch.sh' '[b]utton_watch.sh'; do
  if wait_process "$pattern" 90; then ok "process $pattern"; else bad "process missing after wait: $pattern"; fi
done

if ps w 2>/dev/null | grep '[m]ha_master.*-b' >/dev/null 2>&1; then
  ok 'mha_master running with -b'
else
  bad 'mha_master -b not detected'
fi

if ps w 2>/dev/null | grep '[m]zigbee_agent' >/dev/null 2>&1; then warn 'mzigbee_agent seen; post_init guard should keep killing it'; else ok 'mzigbee_agent stopped'; fi

G33="$(cat /sys/class/gpio/gpio33/value 2>/dev/null)"
G18="$(cat /sys/class/gpio/gpio18/value 2>/dev/null)"
[ "$G33" = 1 ] && ok 'GPIO33=1 normal JN5189 boot' || bad "GPIO33=$G33"
[ "$G18" = 0 ] && ok 'GPIO18=0 reset released' || bad "GPIO18=$G18"

if netstat -lnt 2>/dev/null | grep ':1888 ' >/dev/null 2>&1; then
  bad 'ISP port 1888 still listening after final reboot'
else
  ok 'ISP port 1888 closed'
fi

[ -s /tmp/post_init.log ] && ok 'post_init executed' || bad 'post_init log missing/empty'

if [ -s /tmp/factory_reset_guard_boot.status ]; then
  if grep '^phase=fw_manager_after_isolation$' /tmp/factory_reset_guard_boot.status >/dev/null 2>&1; then
    ok 'Factory Reset Guard isolated /dev/input before fw_manager'
  else
    bad "Factory Reset Guard unexpected phase=$(sed -n 's/^phase=//p' /tmp/factory_reset_guard_boot.status | head -n1)"
  fi
else
  bad 'Factory Reset Guard status missing'
fi

if [ -s /tmp/gpio_button_watch.status ]; then
  grep '^enabled=1$' /tmp/gpio_button_watch.status >/dev/null 2>&1 && \
  grep '^dry_run=0$' /tmp/gpio_button_watch.status >/dev/null 2>&1 && \
  ok 'GPIO button watcher active in live mode' || bad 'GPIO button watcher status is not live mode'
else
  bad 'GPIO button watcher status missing'
fi

if [ -s /tmp/service_trim.status ]; then
  ok "service trim status phase=$(sed -n 's/^phase=//p' /tmp/service_trim.status | head -n1)"
else
  warn 'service trim status not ready yet; it starts with an intentional 120 s delay'
fi

SSID_BYTES="$(wc -c < /data/m1s_wifi/safe/ssid 2>/dev/null)"
PASS_BYTES="$(wc -c < /data/m1s_wifi/safe/pass 2>/dev/null)"
case "$SSID_BYTES" in ''|0) bad 'recovery SSID missing' ;; *) ok "recovery SSID stored (${SSID_BYTES} bytes; hidden)" ;; esac
case "$PASS_BYTES" in ''|0) bad 'recovery password missing' ;; *) ok "recovery password stored (${PASS_BYTES} bytes; hidden)" ;; esac

grep 'M1S_NETWORK_WIFI_DHCP_HOOK_V1' /data/m1s_wifi/wifi_apply_candidate.sh >/dev/null 2>&1 \
  && ok 'Wi-Fi/static-IP safety hook active' || bad 'Wi-Fi/static-IP safety hook missing'
[ -x /data/m1s_wifi/wifi_apply_candidate.real.sh ] && ok 'original Wi-Fi candidate handler preserved' || bad 'original Wi-Fi candidate handler missing'

if [ -e /data/m1s_wifi/actions_enabled ]; then
  echo 'wifi_recovery_auto_ap=ENABLED'
else
  echo 'wifi_recovery_auto_ap=SAFETY_DISABLED'
fi

echo '=== RECENT LOGS ==='
tail -n 50 /tmp/post_init.log 2>/dev/null || true
tail -n 30 /tmp/m1s_network.log 2>/dev/null || true
tail -n 30 /tmp/m1s_wifi_manager.log 2>/dev/null || true

if [ "$FAIL" -eq 0 ]; then
  echo 'ULTIMATE_POSTBOOT_OK'
  exit 0
fi

echo 'ULTIMATE_POSTBOOT_FAILED'
exit 1
