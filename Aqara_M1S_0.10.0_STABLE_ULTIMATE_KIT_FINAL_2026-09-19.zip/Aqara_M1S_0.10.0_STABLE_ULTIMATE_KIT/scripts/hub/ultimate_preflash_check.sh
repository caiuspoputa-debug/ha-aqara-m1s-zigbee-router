#!/bin/sh
# Aqara M1S v0.10.0 Stable Ultimate - strict read-only gate before JN5189 ISP/backup/flash.
# Does not print SSID, Wi-Fi password, MQTT password or MiIO token.

EXPECTED_MODEL='lumi.gateway.aeu01'
EXPECTED_MANAGER_MD5='186d81b3f459c43463d25103cda835ac'
FAIL=0

ok()   { echo "OK: $*"; }
warn() { echo "WARN: $*"; }
bad()  { echo "FAIL: $*"; FAIL=1; }

MODEL="$(getprop ro.product.model 2>/dev/null)"
[ "$MODEL" = "$EXPECTED_MODEL" ] && ok "model=$MODEL" || bad "model=$MODEL expected=$EXPECTED_MODEL"

for f in \
  /data/scripts/post_init.sh \
  /data/scripts/jn5189_enter_isp_1888.sh \
  /data/scripts/jn5189_close_isp_1888.sh \
  /data/scripts/jn5189_boot_router.sh \
  /data/scripts/factory_reset_guard_boot.sh \
  /data/scripts/service_trim.sh \
  /data/scripts/gpio_button_watch.sh \
  /data/m1s_button/button_watch.sh \
  /data/m1s_button/m1s_mqtt_publish.sh \
  /data/m1s_network/network_manager.sh \
  /data/m1s_network/wifi_apply_candidate_wrapper.sh \
  /data/m1s_wifi/wifi_manager.sh \
  /data/m1s_wifi/wifi_apply_candidate.sh \
  /data/m1s_wifi/wifi_apply_candidate.real.sh \
  /data/scripts/wifi_manager_start.sh \
  /data/scripts/wifi_portal_start.sh
do
  if [ -x "$f" ]; then
    /bin/sh -n "$f" >/dev/null 2>&1 && ok "$f" || bad "syntax $f"
  else
    bad "missing/not executable $f"
  fi
done

if command -v md5sum >/dev/null 2>&1; then
  MGR_MD5="$(md5sum /data/m1s_network/network_manager.sh 2>/dev/null | awk '{print $1}')"
  [ "$MGR_MD5" = "$EXPECTED_MANAGER_MD5" ] && ok "network_manager fixed md5=$MGR_MD5" || bad "network_manager md5=$MGR_MD5 expected=$EXPECTED_MANAGER_MD5"
else
  bad "md5sum unavailable"
fi

grep 'M1S_NETWORK_WIFI_DHCP_HOOK_V1' /data/m1s_wifi/wifi_apply_candidate.sh >/dev/null 2>&1 \
  && ok 'Wi-Fi DHCP safety hook active' || bad 'Wi-Fi DHCP safety hook missing'

SSID_BYTES="$(wc -c < /data/m1s_wifi/safe/ssid 2>/dev/null)"
PASS_BYTES="$(wc -c < /data/m1s_wifi/safe/pass 2>/dev/null)"
case "$SSID_BYTES" in ''|0) bad 'Wi-Fi recovery safe SSID is empty' ;; *) ok "Wi-Fi recovery SSID captured (${SSID_BYTES} bytes; value hidden)" ;; esac
case "$PASS_BYTES" in ''|0) bad 'Wi-Fi recovery safe password is empty' ;; *) ok "Wi-Fi recovery password captured (${PASS_BYTES} bytes; value hidden)" ;; esac

if [ -r /data/m1s_button/m1s_button.conf ]; then
  BROKER_HOST=''; BROKER_PORT=''; MQTT_USERNAME=''; MQTT_PASSWORD=''
  . /data/m1s_button/m1s_button.conf
  if [ -n "$BROKER_HOST" ] && [ -n "$BROKER_PORT" ] && [ -n "$MQTT_USERNAME" ] && [ -n "$MQTT_PASSWORD" ]; then
    ok 'MQTT button configuration populated (values hidden)'
  else
    bad 'MQTT button configuration incomplete'
  fi
else
  bad 'MQTT button configuration missing'
fi

if [ -e /data/m1s_wifi/actions_enabled ]; then
  warn 'automatic AP recovery is ENABLED; on a fresh conversion it is safer to enable only after the simulation test'
else
  ok 'automatic AP recovery still safety-disabled (expected before final recovery test)'
fi

for pattern in '[w]ifi_manager.sh' '[m]1s_wifi_portal_safe.sh'; do
  if ps w 2>/dev/null | grep "$pattern" >/dev/null 2>&1; then
    ok "process $pattern"
  else
    bad "process missing $pattern"
  fi
done

cloud="$(getprop persist.app.cloud_provisioned 2>/dev/null)"
hap="$(getprop persist.app.hap_provisioned 2>/dev/null)"
keep="$(getprop persist.app.hap_keepalive 2>/dev/null)"
paired="$(getprop persist.app.user_paired 2>/dev/null)"
if [ "$cloud" = true ] || [ "$hap" = true ] || [ "$keep" = true ]; then
  ok "stock Wi-Fi boot selection permits STA (cloud=$cloud hap=$hap keepalive=$keep paired=$paired)"
else
  bad 'stock Wi-Fi boot flags indicate AP risk'
fi

if ps w 2>/dev/null | grep '[c]at /dev/ttyS1' >/dev/null 2>&1; then
  bad 'cat /dev/ttyS1 is active; release UART before ISP'
else
  ok 'no cat /dev/ttyS1 reader'
fi

if netstat -lnt 2>/dev/null | grep ':1888 ' >/dev/null 2>&1; then
  warn 'port 1888 already listening; close/re-arm ISP cleanly before backup'
else
  ok 'port 1888 free before ISP'
fi

[ -f /data/scripts/factory_reset_guard_boot.conf ] && \
  grep '^ENABLE_FACTORY_RESET_BOOT_GUARD=1$' /data/scripts/factory_reset_guard_boot.conf >/dev/null 2>&1 \
  && ok 'Factory Reset Guard configured enabled' || bad 'Factory Reset Guard not configured enabled'

[ -f /data/scripts/service_trim.conf ] && \
  grep '^ENABLE_SERVICE_TRIM=1$' /data/scripts/service_trim.conf >/dev/null 2>&1 \
  && ok 'service trim configured enabled' || bad 'service trim not configured enabled'

if [ "$FAIL" -eq 0 ]; then
  echo 'ULTIMATE_PREFLASH_OK'
  exit 0
fi

echo 'ULTIMATE_PREFLASH_FAILED - STOP BEFORE JN5189 FLASH'
exit 1
