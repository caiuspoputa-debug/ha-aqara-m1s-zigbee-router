# Validation Report - Aqara M1S 0.10.0 STABLE ULTIMATE KIT

Data build: 2026-09-19
Target: Aqara M1S Gen 1, model `lumi.gateway.aeu01`

## Surse principale validate

1. `Aqara_M1S_WORKING_v0.9_SAFE_STATIC_IP_2026-09-18.zip`
   - SHA256 sursa: `7d8a202df0d3a757ff6e6934ae6d58cd66ac97d44149be976943e9840d5d131d`
   - lista interna SHA256 a fost verificata integral inainte de reutilizare.

2. `Aqara_M1S_Complete_Kit_v0.5.7_FINAL_UPDATED_2026-08-09(3).zip`
   - SHA256 sursa: `230904889ea51463e1e76f42ffe8c81d16ad828cd3125e23617ccd42e5dd592c`
   - lista interna SHA256 a fost verificata integral inainte de reutilizarea modulului Wi-Fi Recovery si a utilitarelor.

## Firmware JN5189

- fisier: `jn5189_router_rgb_lux_rejoin_test.bin`
- dimensiune: 209296 bytes
- SHA256: `a1a1f302be9e3ab95fd6a3b8f4ac260e1f397fec275fb3e3caf8418cd75e7a2f`
- identic cu firmware-ul validat din kiturile anterioare.

## Core v0.10.0

Core-ul este derivat din v0.9. Nu au fost eliminate functiile v0.8 STRICT10/HOLD.

Modificarea functionala deliberata din `network_manager.sh` este exact compatibilitatea recunoscuta de integrarea HA actuala:
- MD5 v0.9 original: `0cdf8f306908e0fab861c33adb4b6810`
- MD5 v0.10.0 fixed: `186d81b3f459c43463d25103cda835ac`

Aceasta corectie rezolva:
- validatorul IPv4 pentru shell-ul BusyBox al hubului;
- curatarea lock-ului fara `rmdir`, utilitar absent pe hubul verificat.

Wrapperul Wi-Fi pastreaza markerul de protocol `M1S_NETWORK_WIFI_DHCP_HOOK_V1` si curata lock-ul HA prin `rm -r` la iesire.

Toate scripturile shell din core au trecut `BusyBox sh -n` in build.

## Wi-Fi Recovery

Payloadul de recovery provine din Complete Kit v0.5.7 UPDATED, dupa verificarea checksumurilor sursei.

- fisierele `safe/ssid` si `safe/pass` din pachet au dimensiune zero;
- installerul captureaza credentialele curente direct de pe hub;
- credentialele nu sunt afisate de verificatoare;
- actiunile AP automate raman safety-disabled implicit;
- hook-ul managerului de retea este instalat si verificat dupa recovery.

Toate scripturile shell din recovery au trecut `BusyBox sh -n` in build.

## Installer unic

`m1s_ultimate_hub_prep_v0.10.0.tgz`:
- verifica modelul exact;
- verifica MD5-urile payloadurilor interne;
- instaleaza core;
- instaleaza recovery;
- verifica hook-ul de retea;
- instaleaza diagnostice;
- ruleaza `ultimate_preflash_check.sh`;
- nu contine nicio comanda de erase/write JN5189.

## Backup + Flash safety gate

Backup:
- doua citiri complete independente de 646656 bytes;
- ambele trebuie sa aiba dimensiunea exacta;
- SHA256 A trebuie sa fie identic cu SHA256 B;
- numai atunci se creeaza `BACKUP_PAIR_OK_<IP>.txt`.

Flash:
- refuza operatia fara markerul de backup;
- markerul trebuie sa apartina acelui Hub IP;
- ambele fisiere de backup trebuie sa existe;
- ambele sunt reverificate ca dimensiune si SHA256;
- firmware-ul este verificat ca dimensiune si SHA256 inainte de ERASE;
- se face ERASE + WRITE;
- nu se face readback imediat dupa WRITE, conform fluxului SPSDK validat anterior.

## Home Assistant

Snapshot inclus: v0.21.7.

Sursa a fost reconstruita din arhiva locala v0.21.6 plus modificarile curente din repo, apoi **toate cele 29 de fisiere** din `custom_components/aqara_m1s_zigbee_router` au fost comparate cu SHA-urile Git blob ale ramurii `main`. Rezultat: coincidenta exacta pentru toate fisierele.

Compilarea Python a snapshotului a trecut in mediul de build.

## Ce este validat automat in buildul final

- integritatea tuturor fisierelor prin `SHA256SUMS.txt`;
- extragerea fara erori a ZIP-ului final;
- extragerea fara erori a tuturor TGZ-urilor imbricate;
- sintaxa BusyBox pentru toate scripturile `.sh` din payloaduri;
- firmware exact ca dimensiune/hash;
- manager de retea exact ca MD5;
- credentialele Wi-Fi din payloadul recovery sunt goale;
- manifestul HA este v0.21.7;
- snapshotul HA este Python-compilabil.

## Limitari declarate

- Mediul de build nu are un hub Aqara M1S fizic conectat, deci nu poate demonstra end-to-end un flash real pe un hub stock nou.
- Mediul de build nu are runtime PowerShell, deci scripturile PowerShell pot fi auditate structural si prin continut, dar nu executate aici cu parser/runtime PowerShell.
- Din acest motiv, denumirea `STABLE ULTIMATE` descrie kitul consolidat si portile de siguranta, nu pretinde ca aceasta combinatie exacta v0.10.0 a fost deja rulata fizic cap-coada pe un hub nou.
- Primul hub nou pe care se ruleaza 0.10.0 trebuie tratat ca validarea hardware finala; fluxul este construit astfel incat sa se opreasca inainte de flash daca pregatirea sau backupul nu sunt corecte.

## Revizie finala de consistenta

In revizia finala a pachetului 0.10.0 a fost corectat exclusiv README-ul intern al modulului Wi-Fi Recovery:
- eliminata referinta istorica Home Assistant v0.5.7;
- markerul documentat este acum exact `WIFI_RECOVERY_V0_10_0_INSTALL_OK`;
- clarificat ca snapshotul HA inclus este v0.21.7.

Modificarea README-ului a impus regenerarea arhivei Wi-Fi Recovery si a installerului unificat, cu MD5-urile interne si MD5-ul de transfer actualizate. Codul operational al recovery-ului, core-ul v0.10.0, backupul si flash-ul JN5189 nu au fost schimbate in aceasta revizie.
