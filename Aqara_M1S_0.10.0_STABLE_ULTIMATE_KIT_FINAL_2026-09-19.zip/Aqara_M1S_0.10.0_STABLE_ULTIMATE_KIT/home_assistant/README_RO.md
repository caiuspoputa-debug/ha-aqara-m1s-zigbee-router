# Home Assistant - snapshot inclus

Fisier: `ha-aqara-m1s-zigbee-router-v0.21.7-SNAPSHOT.zip`

Acesta este un snapshot offline al componentei `aqara_m1s_zigbee_router` v0.21.7.

La construirea kitului, toate cele 29 de fisiere din `custom_components/aqara_m1s_zigbee_router` au fost comparate cu SHA-urile Git blob din ramura `main` a repo-ului `caiuspoputa-debug/ha-aqara-m1s-zigbee-router` si au coincis exact.

Daca integrarea HACS este deja instalata si actualizata in Home Assistant, nu trebuie reinstalata pentru fiecare hub nou. Snapshotul este inclus pentru reproducibilitate/offline/recovery.
