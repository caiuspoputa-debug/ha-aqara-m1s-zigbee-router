# Changelog - Aqara M1S 0.10.0 STABLE ULTIMATE KIT

## 0.10.0 - 2026-09-19

- Baza Linux porneste din `Aqara_M1S_WORKING_v0.9_SAFE_STATIC_IP_2026-09-18`.
- Pastreaza toate functiile v0.8 STRICT10/HOLD, Factory Reset Guard, GPIO watcher, service trim, bridge MQTT, JN5189 ISP helpers si topic stabil pentru buton.
- `network_manager.sh` este corectat exact conform compatibilitatii validate de integrarea HA v0.21.7:
  - validarea IPv4 nu mai depinde de efectul unui subshell incompatibil;
  - eliminarea lock-ului foloseste `rm -r`, disponibil pe BusyBox-ul real al hubului, in loc de `rmdir`.
- MD5 manager corectat: `186d81b3f459c43463d25103cda835ac`.
- Wi-Fi Recovery recuperat din Complete Kit v0.5.7 UPDATED si integrat cu managerul de retea v0.10.0.
- Wrapperul Wi-Fi curata sigur lock-ul HA cu `rm -r` la iesire.
- Recovery AP automat ramane dezactivat implicit pana la testul de simulare.
- Adaugat installer unic `m1s_ultimate_hub_prep_v0.10.0.tgz` pentru core + Wi-Fi recovery + diagnostice + preflight.
- Adaugat `ultimate_preflash_check.sh` care blocheaza fluxul daca lipsesc dependentele sau configuratia este incompleta.
- Adaugat `verify_hub_ultimate.sh` pentru verificare post-reboot cu asteptare pentru serviciile lente.
- Backup JN5189 consolidat: doua citiri complete de 646656 bytes, SHA256 identic, marker de siguranta.
- Flash JN5189 consolidat: refuza erase/write fara backup gate valid si reverifica ambele fisiere de backup.
- Pastrat fluxul validat fara readback imediat dupa WRITE.
- Firmware JN5189 neschimbat: 209296 bytes, SHA256 `a1a1f302be9e3ab95fd6a3b8f4ac260e1f397fec275fb3e3caf8418cd75e7a2f`.
- Inclus snapshot exact al integrarii Home Assistant v0.21.7, verificat fisier-cu-fisier fata de `main` din repo.
- Adaugata documentatie unica stock -> pregatire -> backup -> flash -> Zigbee2MQTT -> HA -> reboot -> recovery test -> IP static.
