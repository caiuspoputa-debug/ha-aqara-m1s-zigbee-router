# Aqara M1S 0.10.0 STABLE ULTIMATE KIT

## Scop

Acesta este kitul unic, personal/local, pentru conversia unui **Aqara M1S Gen 1 `lumi.gateway.aeu01`** intr-un router Zigbee JN5189 integrat cu Home Assistant.

Kitul combina traseul validat din versiunile anterioare cu:
- core-ul cel mai nou derivat din v0.9 SAFE STATIC IP;
- STRICT10 + HOLD events + bridge MQTT pentru butonul fizic;
- Factory Reset Guard + GPIO button watcher + service trim;
- manager de IP static corectat pentru BusyBox-ul real al hubului;
- Wi-Fi Recovery din Complete Kit v0.5.7, legat de managerul de retea nou;
- firmware-ul JN5189 validat, cu lux/RGB/rejoin;
- backup dublu obligatoriu inainte de flash;
- verificare stricta inainte de flash si verificare completa dupa reboot;
- snapshot exact Home Assistant `aqara_m1s_zigbee_router` v0.21.7.

**Important:** flash-ul JN5189 NU este inclus in installerul automat. Este separat intentionat, pentru ca erase/write sa fie imposibil pana cand exista doua backup-uri complete, identice.

---

# 0. REGULI DE SIGURANTA

1. Nu continua la flash daca nu vezi exact `ULTIMATE_PREFLASH_OK`.
2. Nu continua la flash daca backup-ul nu se termina cu `BACKUP_PAIR_OK`.
3. Scriptul de flash refuza automat erase/write daca lipseste markerul de backup sau daca cele doua fisiere de backup nu mai corespund hash-ului salvat.
4. Dupa WRITE nu face readback imediat. Fluxul validat inchide ISP si booteaza routerul.
5. Daca orice pas da `FAIL`, `ERROR`, `MISMATCH` sau lipseste markerul asteptat, opreste secventa acolo.

---

# 1. PREGATIRE PC + HUB STOCK

Pe hubul stock:
- hubul trebuie adaugat/configurat in Xiaomi Home;
- Wi-Fi 2.4 GHz functional;
- recomandat DHCP reservation pentru adresa curenta;
- ai nevoie de tokenul MiIO al hubului.

Pe Windows, deschide PowerShell in radacina kitului si ruleaza:

```powershell
.\scripts\windows\Verify-Kit.ps1
.\scripts\windows\Check-Prerequisites.ps1
```

Rezultate asteptate:

```text
KIT_SHA256_OK
PREREQUISITES_OK
```

Daca `py.exe` nu este in locatia implicita, poti indica launcherul/Python-ul instalat, de exemplu:

```powershell
.\scripts\windows\Check-Prerequisites.ps1 -Python py
```

---

# 2. ACTIVEAZA TELNET TEMPORAR

```powershell
.\scripts\windows\Enable-TemporaryTelnet.ps1 -HubIp HUB_IP
```

Scriptul cere tokenul MiIO ascuns, il verifica mai intai cu `Device.info()` si abia apoi trimite comanda de activare Telnet.

Rezultate asteptate:

```text
MIIO_TOKEN_OK
TELNET_REQUEST_SENT HUB_IP
```

Conectare:

```text
telnet HUB_IP
user: admin
parola: goala
```

---

# 3. TRANSFERA SI RULEAZA INSTALLERUL UNIC DE PREGATIRE

Pe hub, in Telnet:

```sh
rm -f /tmp/m1s_ultimate_hub_prep_v0.10.0.tgz
nc -l -p 12345 > /tmp/m1s_ultimate_hub_prep_v0.10.0.tgz
```

Comanda ramane in asteptare. Pe Windows, din radacina kitului:

```powershell
.\scripts\windows\Send-FileToM1S.ps1 -HubIp HUB_IP -Path .\installers\m1s_ultimate_hub_prep_v0.10.0.tgz -Port 12345
```

Dupa terminarea transferului, inapoi pe hub:

```sh
md5sum /tmp/m1s_ultimate_hub_prep_v0.10.0.tgz
```

MD5 asteptat pentru acest kit:

```text
6eff82e0acd07d7d5f7bef752d556577
```

Daca hash-ul difera, NU continua. Retransfera fisierul.

Instalare:

```sh
rm -rf /tmp/m1s_ultimate_prep
mkdir -p /tmp/m1s_ultimate_prep
tar -xzf /tmp/m1s_ultimate_hub_prep_v0.10.0.tgz -C /tmp/m1s_ultimate_prep
/bin/sh /tmp/m1s_ultimate_prep/install.sh
```

Installerul:
- verifica modelul exact;
- verifica hashurile componentelor interne;
- instaleaza core v0.10.0;
- instaleaza Wi-Fi Recovery fara sa includa credentiale Wi-Fi in kit;
- captureaza local pe hub SSID/parola curente pentru recovery;
- instaleaza hook-ul DHCP/static-IP;
- instaleaza diagnosticele;
- ruleaza preflight strict;
- **nu flasheaza JN5189**.

Finalul corect trebuie sa contina:

```text
ULTIMATE_PREFLASH_OK
ULTIMATE_HUB_PREPARED_V0_10_0
```

Optional, poti repeta poarta inainte de ISP:

```sh
/data/scripts/ultimate_preflash_check.sh
```

Trebuie sa se termine cu:

```text
ULTIMATE_PREFLASH_OK
```

---

# 4. INTRA JN5189 IN ISP

Pe hub:

```sh
/data/scripts/jn5189_enter_isp_1888.sh
```

Verifica sa apara listenerul ISP pe portul 1888 si starea GPIO asteptata de script. Nu porni backup-ul daca scriptul raporteaza eroare.

---

# 5. BACKUP DUBLU OBLIGATORIU

Pe Windows:

```powershell
.\scripts\windows\JN5189-Backup-PAIR-VERIFY.ps1 -HubIp HUB_IP
```

Scriptul citeste **de doua ori flash-ul complet de 646656 bytes**, verifica dimensiunile si cere SHA256 identic.

Finalul obligatoriu:

```text
BACKUP_PAIR_OK SHA256=...
BACKUP_GATE=...\backups\BACKUP_PAIR_OK_HUB_IP.txt
```

Daca vezi `BACKUP_HASH_MISMATCH`, STOP. Nu flashea.

---

# 6. FLASH JN5189

Numai dupa `BACKUP_PAIR_OK`:

```powershell
.\scripts\windows\JN5189-Flash-WRITE.ps1 -HubIp HUB_IP
```

Scriptul verifica automat:
- markerul backupului pentru acel IP;
- existenta ambelor backup-uri;
- dimensiunea ambelor backup-uri;
- SHA256-ul ambelor backup-uri;
- firmware exact 209296 bytes;
- firmware SHA256 exact `a1a1f302be9e3ab95fd6a3b8f4ac260e1f397fec275fb3e3caf8418cd75e7a2f`.

Apoi face ERASE + WRITE.

Final corect:

```text
FLASH_WRITE_OK bytes=209296 SHA256=A1A1F302BE9E3AB95FD6A3B8F4AC260E1F397FEC275FB3E3CAF8418CD75E7A2F
```

**Nu face readback imediat dupa WRITE.**

---

# 7. INCHIDE ISP SI BOOTEAZA ROUTERUL

Pe hub:

```sh
/data/scripts/jn5189_close_isp_1888.sh
/data/scripts/jn5189_boot_router.sh
```

Apoi in Zigbee2MQTT activeaza `Permit join` si asteapta aparitia routerului Lumi/BDB-Router.

---

# 8. HOME ASSISTANT

Integrarea curenta pentru acest kit este **v0.21.7**.

Daca repo-ul HACS `caiuspoputa-debug/ha-aqara-m1s-zigbee-router` este deja instalat si actualizat, **nu trebuie reinstalata integrarea pentru fiecare hub**. Adaugi doar noul hub in integrare.

Pentru reproducibilitate/offline, kitul include exact snapshotul v0.21.7:

```text
home_assistant/ha-aqara-m1s-zigbee-router-v0.21.7-SNAPSHOT.zip
```

Adauga noul hub in Home Assistant inainte de rebootul final, conform fluxului validat.

---

# 9. REBOOT FINAL + VERIFICARE

Pe hub:

```sh
sync
reboot
```

Dupa ce hubul a revenit online, reconecteaza-te prin Telnet si ruleaza:

```sh
/data/scripts/verify_hub_ultimate.sh
```

Scriptul asteapta automat serviciile lente. Finalul dorit:

```text
ULTIMATE_POSTBOOT_OK
```

`service trim` are intentionat o intarziere de 120 s. Daca apare doar avertismentul ca statusul lui nu este gata, poti repeta verificarea dupa cateva minute.

Verifica practic:
- player/radio Home Assistant;
- ring light;
- senzorul lux;
- butonul fizic si evenimentele click/HOLD;
- routerul in Zigbee2MQTT.

---

# 10. TEST WI-FI RECOVERY IN MOD SIGUR

La instalare, recovery-ul automat AP ramane intentionat dezactivat. Intai simulam pierderea IPv4 fara sa schimbam reteaua:

```sh
touch /data/m1s_wifi/test_noip
sleep 20
tail -n 30 /tmp/m1s_wifi_manager.log
rm -f /data/m1s_wifi/test_noip
```

In aceasta etapa trebuie sa vezi in log ca recovery-ul **ar** porni AP, dar nu trebuie sa modifice efectiv reteaua deoarece `actions_enabled` lipseste.

Numai dupa ce simularea este buna, daca doresti recovery AP automat:

```sh
touch /data/m1s_wifi/actions_enabled
chmod 600 /data/m1s_wifi/actions_enabled
sync
```

Dezactivare ulterioara:

```sh
rm -f /data/m1s_wifi/actions_enabled
```

Portalul de recovery poate fi accesat, cand AP-ul este activ, la una dintre adresele suportate de modul:

```text
http://192.168.49.1:8080/
http://192.168.1.1:8080/
```

---

# 11. IP STATIC

Seteaza IP static **abia dupa ce hubul este stabil si verificat**. Pentru acest kit foloseste interfata integrarii HA v0.21.7.

Managerul din hub este deja versiunea BusyBox-fixed, MD5:

```text
186d81b3f459c43463d25103cda835ac
```

Fluxul testeaza adresa candidat, verifica identitatea MAC si confirma abia apoi adresa. La schimbarea Wi-Fi, hook-ul readuce reteaua in DHCP inainte de candidatul Wi-Fi, pentru a evita blocarea hubului pe o configuratie statica veche.

---

# DATE DE REFERINTA

Firmware JN5189:

```text
fisier: firmware/jn5189_router_rgb_lux_rejoin_test.bin
bytes: 209296
SHA256: a1a1f302be9e3ab95fd6a3b8f4ac260e1f397fec275fb3e3caf8418cd75e7a2f
```

Network manager v0.10.0 fixed:

```text
MD5: 186d81b3f459c43463d25103cda835ac
```

---

# NOTA PRIVIND ACEST KIT

Acesta este un **kit PERSONAL/LOCAL**. Configuratia MQTT pentru bridge-ul butonului este preluata din kitul tau validat v0.9 si este destinata retelei tale. Nu publica arhiva asa cum este pe GitHub sau in alta parte fara o varianta sanitizata.

Kitul NU contine tokenul MiIO si NU contine SSID/parola Wi-Fi. Modulul de recovery isi captureaza credentialele curente direct de pe hub in timpul instalarii.

Pentru detalii despre ce a fost verificat si ce nu poate fi verificat fara hardware real, vezi `docs/VALIDATION_REPORT.md`.
