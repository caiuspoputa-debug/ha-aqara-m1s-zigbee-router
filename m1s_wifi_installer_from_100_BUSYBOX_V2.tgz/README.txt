M1S Wi-Fi installer from hub .100 — BusyBox safe, revision 2

Fixes:
- backup accepts missing optional files;
- backup is verified before any modification;
- rollback runs only after mutation actually starts;
- rollback restores only items that existed before installation;
- no tee, no dirname --, no forced AP/STA transition.

Expected final line:
INSTALL_100_OK
