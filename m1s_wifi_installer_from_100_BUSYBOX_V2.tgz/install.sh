#!/bin/sh
set -e

BASE=/data/m1s_wifi
SCRIPTS=/data/scripts
PKG_DIR="$(CDPATH= cd "$(dirname "$0")" && pwd)"
PAYLOAD="$PKG_DIR/payload_100.tgz"
STAMP="$(date +%Y%m%d_%H%M%S)"
WORK="/tmp/m1s_wifi_install.$$"
OLD_BASE="/data/m1s_wifi.before_$STAMP"
BACKUP="/data/m1s_wifi_backup_$STAMP.tgz"
LOG="/tmp/m1s_wifi_install_$STAMP.log"
START1="$SCRIPTS/wifi_manager_start.sh"
START2="$SCRIPTS/wifi_portal_start.sh"
OLD_START1="/data/wifi_manager_start.before_$STAMP.sh"
OLD_START2="/data/wifi_portal_start.before_$STAMP.sh"
MUTATION_STARTED=0
INSTALL_OK=0
HAD_BASE=0
HAD_START1=0
HAD_START2=0
PRESERVE_ACTIONS=0

say()
{
    echo "$*"
    echo "$*" >>"$LOG"
}

fail()
{
    say "EROARE: $*"
    exit 1
}

stop_project()
{
    for pattern in \
        '[w]ifi_manager.sh' \
        '[m]1s_wifi_portal_safe.sh' \
        '[a]p_watchdog.sh' \
        '[m]1s_captive_redirect.sh' \
        '[p]ortal_fifo.sh'
    do
        for pid in $(ps | awk -v p="$pattern" '$0 ~ p {print $1}'); do
            kill "$pid" 2>/dev/null || true
        done
    done
    sleep 1
}

restore_old()
{
    say "=== ROLLBACK AUTOMAT ==="
    stop_project

    rm -rf "$BASE"
    rm -f "$START1" "$START2"

    if [ "$HAD_BASE" -eq 1 ] && [ -d "$OLD_BASE" ]; then
        mv "$OLD_BASE" "$BASE"
    fi
    if [ "$HAD_START1" -eq 1 ] && [ -f "$OLD_START1" ]; then
        mv "$OLD_START1" "$START1"
    fi
    if [ "$HAD_START2" -eq 1 ] && [ -f "$OLD_START2" ]; then
        mv "$OLD_START2" "$START2"
    fi

    sync
    [ -x "$START1" ] && "$START1" >>"$LOG" 2>&1 || true
    [ -x "$START2" ] && "$START2" >>"$LOG" 2>&1 || true
    say "ROLLBACK_TERMINAT"
}

cleanup()
{
    rc=$?
    rm -rf "$WORK"
    if [ "$rc" -ne 0 ] && [ "$MUTATION_STARTED" -eq 1 ] && [ "$INSTALL_OK" -eq 0 ]; then
        restore_old
    fi
    exit "$rc"
}
trap cleanup EXIT INT TERM

[ -f "$PAYLOAD" ] || fail "lipseste payload_100.tgz"
mkdir -p "$WORK" "$SCRIPTS"

say "=== VALIDARE PACHET .100 ==="
tar -tzf "$PAYLOAD" >"$WORK/list.txt" 2>>"$LOG" || fail "arhiva nu poate fi citita"

for required in \
    data/m1s_wifi/wifi_manager.sh \
    data/m1s_wifi/m1s_wifi_portal_safe.sh \
    data/m1s_wifi/restore_sta.sh \
    data/m1s_wifi/ap_watchdog.sh \
    data/m1s_wifi/candidate_failed_to_ap.sh \
    data/scripts/wifi_manager_start.sh \
    data/scripts/wifi_portal_start.sh
do
    grep -x "$required" "$WORK/list.txt" >/dev/null 2>&1 || fail "lipseste: $required"
done

tar -xzf "$PAYLOAD" -C "$WORK" 2>>"$LOG" || fail "extragerea a esuat"

for script in "$WORK"/data/m1s_wifi/*.sh "$WORK"/data/scripts/*.sh; do
    [ -f "$script" ] || continue
    /bin/sh -n "$script" 2>>"$LOG" || fail "sintaxa invalida: $script"
done

[ -d "$BASE" ] && HAD_BASE=1
[ -f "$START1" ] && HAD_START1=1
[ -f "$START2" ] && HAD_START2=1
[ -e "$BASE/actions_enabled" ] && PRESERVE_ACTIONS=1

say "=== BACKUP SIGUR ==="
BACKUP_LIST=""
[ "$HAD_BASE" -eq 1 ] && BACKUP_LIST="$BACKUP_LIST data/m1s_wifi"
[ "$HAD_START1" -eq 1 ] && BACKUP_LIST="$BACKUP_LIST data/scripts/wifi_manager_start.sh"
[ "$HAD_START2" -eq 1 ] && BACKUP_LIST="$BACKUP_LIST data/scripts/wifi_portal_start.sh"

if [ -n "$BACKUP_LIST" ]; then
    (cd / && tar -czf "$BACKUP" $BACKUP_LIST) 2>>"$LOG" || \
        fail "backup-ul a esuat; nimic nu a fost modificat"
    tar -tzf "$BACKUP" >/dev/null 2>>"$LOG" || \
        fail "backup-ul nu poate fi verificat; nimic nu a fost modificat"
    say "Backup: $BACKUP"
else
    say "Nu exista instalare anterioara; backup omis."
fi

say "=== OPRIRE SERVICII PROIECT ==="
stop_project

say "=== INLOCUIRE CURATA ==="
[ ! -e "$OLD_BASE" ] || fail "exista deja $OLD_BASE"
[ ! -e "$OLD_START1" ] || fail "exista deja $OLD_START1"
[ ! -e "$OLD_START2" ] || fail "exista deja $OLD_START2"

MUTATION_STARTED=1
[ "$HAD_BASE" -eq 1 ] && mv "$BASE" "$OLD_BASE"
[ "$HAD_START1" -eq 1 ] && mv "$START1" "$OLD_START1"
[ "$HAD_START2" -eq 1 ] && mv "$START2" "$OLD_START2"

mkdir -p "$BASE" "$SCRIPTS"
cp -Rp "$WORK/data/m1s_wifi/." "$BASE/" || fail "copierea m1s_wifi a esuat"
cp -p "$WORK/data/scripts/wifi_manager_start.sh" "$START1" || fail "copiere manager start esuata"
cp -p "$WORK/data/scripts/wifi_portal_start.sh" "$START2" || fail "copiere portal start esuata"

chown -R admin:0 "$BASE" 2>>"$LOG" || true
chown admin:0 "$START1" "$START2" 2>>"$LOG" || true
chmod 700 "$BASE"/*.sh "$START1" "$START2"
chmod 600 "$BASE/safe/ssid" "$BASE/safe/pass" 2>/dev/null || true

if [ "$PRESERVE_ACTIONS" -eq 1 ]; then
    : >"$BASE/actions_enabled"
    chmod 644 "$BASE/actions_enabled"
else
    rm -f "$BASE/actions_enabled"
fi
sync

say "=== PORNIRE SERVICII ==="
"$START1" >>"$LOG" 2>&1 || fail "wifi_manager_start.sh a esuat"
"$START2" >>"$LOG" 2>&1 || fail "wifi_portal_start.sh a esuat"
sleep 2

ps | grep '[w]ifi_manager.sh' >/dev/null 2>&1 || fail "wifi_manager.sh nu ruleaza"
ps | grep '[m]1s_wifi_portal_safe.sh' >/dev/null 2>&1 || fail "portalul nu ruleaza"

INSTALL_OK=1
rm -rf "$OLD_BASE"
rm -f "$OLD_START1" "$OLD_START2"
sync

say "=== INSTALARE REUSITA ==="
say "Nu a fost executat wifi_start.sh AP sau STA."
say "actions_enabled pastrat: $PRESERVE_ACTIONS"
say "Log: $LOG"
[ -f "$BACKUP" ] && say "Backup manual: $BACKUP"
echo INSTALL_100_OK
