[CmdletBinding()]
param(
    [string]$RootPath = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path,
    [string]$ChecksumFile = 'SHA256SUMS.txt'
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $RootPath).Path
$listPath = Join-Path $root $ChecksumFile

if (-not (Test-Path -LiteralPath $listPath -PathType Leaf)) {
    throw "Lipseste lista de checksum: $listPath"
}

$results = foreach ($line in Get-Content -LiteralPath $listPath -Encoding UTF8) {
    if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith('#')) {
        continue
    }
    if ($line.Length -lt 67 -or $line.Substring(64, 2) -ne '  ') {
        throw "Linie SHA256SUMS invalida: $line"
    }

    $expected = $line.Substring(0, 64).ToUpperInvariant()
    $relative = $line.Substring(66).Replace('/', [IO.Path]::DirectorySeparatorChar)
    $path = Join-Path $root $relative

    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        [pscustomobject]@{
            File     = $relative
            Status   = 'MISSING'
            Expected = $expected
            Actual   = $null
        }
        continue
    }

    $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToUpperInvariant()
    [pscustomobject]@{
        File     = $relative
        Status   = if ($actual -eq $expected) { 'OK' } else { 'MISMATCH' }
        Expected = $expected
        Actual   = $actual
    }
}

$results | Format-Table File, Status -AutoSize
$failed = @($results | Where-Object Status -ne 'OK')
if ($failed.Count -gt 0) {
    throw "Verificarea kitului a esuat pentru $($failed.Count) fisier(e)."
}

Write-Host "KIT_SHA256_OK: $($results.Count) fisiere verificate."
