[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$HubIp,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [ValidateRange(1, 65535)]
    [int]$Port = 1889
)

$ErrorActionPreference = 'Stop'
$client = [System.Net.Sockets.TcpClient]::new()
try {
    $client.Connect($HubIp, $Port)
    $network = $client.GetStream()
    $file = [System.IO.File]::Create($OutputPath)
    try {
        $network.CopyTo($file)
    }
    finally {
        $file.Dispose()
        $network.Dispose()
    }
}
finally {
    $client.Dispose()
}

$item = Get-Item -LiteralPath $OutputPath
[pscustomobject]@{
    File   = $item.FullName
    Bytes  = $item.Length
    SHA256 = (Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash
}
