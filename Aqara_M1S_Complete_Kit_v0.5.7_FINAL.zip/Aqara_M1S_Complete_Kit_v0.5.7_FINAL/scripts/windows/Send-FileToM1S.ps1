[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$HubIp,

    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path -LiteralPath $_ -PathType Leaf })]
    [string]$Path,

    [ValidateRange(1, 65535)]
    [int]$Port = 12345
)

$ErrorActionPreference = 'Stop'
$file = Get-Item -LiteralPath $Path
$client = [System.Net.Sockets.TcpClient]::new()

try {
    $client.Connect($HubIp, $Port)
    $stream = $client.GetStream()
    $source = [System.IO.File]::OpenRead($file.FullName)
    try {
        $source.CopyTo($stream)
        $stream.Flush()
    }
    finally {
        $source.Dispose()
        $stream.Dispose()
    }
}
finally {
    $client.Dispose()
}

[pscustomobject]@{
    Hub       = $HubIp
    Port      = $Port
    File      = $file.FullName
    BytesSent = $file.Length
    SHA256    = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
}
