[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$HubIp,

    [string]$OutputDirectory = (Join-Path $PWD 'm1s-backups'),

    [ValidateRange(1, 65535)]
    [int]$Port = 1888,

    [string]$Python = 'python'
)

$ErrorActionPreference = 'Stop'
$ExpectedBytes = 646656 # 0x9DE00, FLASH Memory ID 0 reported for JN5189
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$output = Join-Path $OutputDirectory "jn5189_original_flash_${HubIp}_$timestamp.bin"

function Invoke-Dk6Prog {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]]$Arguments)
    & $Python -m spsdk.apps.dk6prog @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "dk6prog failed with exit code $LASTEXITCODE"
    }
}

Write-Host '1/3 Verific dispozitivul...'
Invoke-Dk6Prog -b PYSERIAL -d "socket://${HubIp}:$Port" -n info
Start-Sleep -Seconds 2

Write-Host '2/3 Citesc FLASH Memory ID 0...'
Invoke-Dk6Prog -b PYSERIAL -d "socket://${HubIp}:$Port" -n read -o $output 0x0 $ExpectedBytes 0

$file = Get-Item -LiteralPath $output
if ($file.Length -ne $ExpectedBytes) {
    throw "Backup incomplet: $($file.Length) bytes, asteptat $ExpectedBytes"
}

$hash = Get-FileHash -LiteralPath $output -Algorithm SHA256
Write-Host '3/3 Backup verificat local.'
[pscustomobject]@{
    File   = $file.FullName
    Bytes  = $file.Length
    SHA256 = $hash.Hash
}
