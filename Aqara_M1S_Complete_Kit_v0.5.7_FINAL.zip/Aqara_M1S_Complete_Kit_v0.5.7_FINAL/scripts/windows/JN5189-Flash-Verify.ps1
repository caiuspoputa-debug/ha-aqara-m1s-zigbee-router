[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$HubIp,

    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path -LiteralPath $_ -PathType Leaf })]
    [string]$FirmwarePath,

    [ValidateRange(1, 65535)]
    [int]$Port = 1888,

    [switch]$EraseApplication,

    [string]$ReadbackDirectory = (Join-Path $PWD 'm1s-readback'),

    [string]$Python = 'python'
)

$ErrorActionPreference = 'Stop'
$ExpectedFirmwareHash = 'A1A1F302BE9E3AB95FD6A3B8F4AC260E1F397FEC275FB3E3CAFC8418CD75E7A2F'
$ExpectedFirmwareBytes = 209296
$EraseLength = '0x33200'
$firmware = Get-Item -LiteralPath $FirmwarePath
$sourceHash = (Get-FileHash -LiteralPath $firmware.FullName -Algorithm SHA256).Hash

if ($firmware.Length -ne $ExpectedFirmwareBytes) {
    throw "Dimensiune firmware neasteptata: $($firmware.Length), asteptat $ExpectedFirmwareBytes"
}
if ($sourceHash -ne $ExpectedFirmwareHash) {
    throw "SHA256 firmware diferit. Obtinut $sourceHash, asteptat $ExpectedFirmwareHash"
}

function Invoke-Dk6Prog {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]]$Arguments)
    & $Python -m spsdk.apps.dk6prog @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "dk6prog failed with exit code $LASTEXITCODE"
    }
}

if (-not $PSCmdlet.ShouldProcess(
    "JN5189 la ${HubIp}:$Port",
    "scriere $($firmware.Name), SHA256 $sourceHash"
)) {
    return
}

Write-Host '1/5 Verific dispozitivul...'
Invoke-Dk6Prog -b PYSERIAL -d "socket://${HubIp}:$Port" -n info
Start-Sleep -Seconds 2

if ($EraseApplication) {
    Write-Warning "Sterg numai zona aplicatiei 0x0..$EraseLength; NU intregul cip."
    Invoke-Dk6Prog -b PYSERIAL -d "socket://${HubIp}:$Port" -n erase 0x0 $EraseLength 0
    Start-Sleep -Seconds 2
}
else {
    Write-Host 'Erase omis: actualizare directa a imaginii, cu pastrarea contextului Zigbee.'
}

Write-Host '2/5 Scriu firmware-ul...'
Invoke-Dk6Prog -b PYSERIAL -d "socket://${HubIp}:$Port" -n write 0x0 $firmware.FullName 0
Start-Sleep -Seconds 2

Write-Host '3/5 Citesc inapoi exact lungimea firmware-ului...'
New-Item -ItemType Directory -Path $ReadbackDirectory -Force | Out-Null
$readback = Join-Path $ReadbackDirectory ("readback_{0}_{1}.bin" -f $HubIp, (Get-Date -Format 'yyyyMMdd_HHmmss'))
Invoke-Dk6Prog -b PYSERIAL -d "socket://${HubIp}:$Port" -n read -o $readback 0x0 $firmware.Length 0

Write-Host '4/5 Compar SHA256...'
$readbackHash = (Get-FileHash -LiteralPath $readback -Algorithm SHA256).Hash
if ($readbackHash -ne $sourceHash) {
    throw "READBACK DIFERIT: sursa=$sourceHash readback=$readbackHash"
}

Write-Host '5/5 Flash si readback confirmate.'
[pscustomobject]@{
    Firmware      = $firmware.FullName
    FirmwareBytes = $firmware.Length
    SHA256        = $sourceHash
    Readback      = (Resolve-Path -LiteralPath $readback).Path
    EraseUsed     = [bool]$EraseApplication
}
