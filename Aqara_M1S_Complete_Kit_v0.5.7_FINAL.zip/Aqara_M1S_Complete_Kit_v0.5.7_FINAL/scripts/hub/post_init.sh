#!/bin/sh
# Boot persistent pentru Aqara M1S Gen 1 convertit in JN5189 Router.
# Pastreaza serviciile stock Linux/Wi-Fi/HomeKit/audio, porneste Telnet,
# elibereaza UART-ul JN5189, porneste Routerul si optional serviciile proiectului.

LOG_FILE="/tmp/post_init.log"

log()
{
    echo "$(date) $*" >> "$LOG_FILE"
}

wait_for_wifi()
{
    elapsed=0
    while [ "$elapsed" -lt 120 ]; do
        if ifconfig wlan0 2>/dev/null | grep -q 'inet addr'; then
            return 0
        fi
        sleep 2
        elapsed=$((elapsed + 2))
    done
    return 1
}

start_once()
{
    pattern="$1"
    command="$2"
    if ! ps w 2>/dev/null | grep "$pattern" >/dev/null 2>&1; then
        /bin/sh -c "$command" &
    fi
}

log "post_init start"

# Diagnostic fara SSID/parola: fw_manager.sh alege AP daca toate cele trei
# proprietati Aqara/HomeKit sunt false sau goale. Corectia se face o singura
# data cu aqara_wifi_boot_state.sh fix, nu aici automat la fiecare boot.
cloud_provisioned="$(getprop persist.app.cloud_provisioned 2>/dev/null)"
hap_provisioned="$(getprop persist.app.hap_provisioned 2>/dev/null)"
hap_keepalive="$(getprop persist.app.hap_keepalive 2>/dev/null)"
if [ "$cloud_provisioned" != "true" ] && \
   [ "$hap_provisioned" != "true" ] && \
   [ "$hap_keepalive" != "true" ]; then
    log "WARNING Aqara boot flags inactive: stock fw_manager may select AP"
else
    log "Aqara boot flags permit normal STA selection"
fi

# Serviciile Linux, Wi-Fi, HomeKit si audio originale.
# ATENTIE: -r este pornire normala; nu folosi aici fw_manager.sh -f -r.
fw_manager.sh -r &

(
    if wait_for_wifi; then
        log "Wi-Fi detected"
    else
        log "Wi-Fi wait timeout; continuing"
    fi

    sleep 5

    # Telnet persistent, numai in LAN.
    fw_manager.sh -t -k &
    log "Telnet start requested"

    # Module optionale, doar daca au fost instalate separat.
    if [ -x /data/scripts/wifi_manager_start.sh ]; then
        /data/scripts/wifi_manager_start.sh >> "$LOG_FILE" 2>&1 || true
        log "Wi-Fi recovery manager start requested"
    fi
    if [ -x /data/scripts/wifi_portal_start.sh ]; then
        /data/scripts/wifi_portal_start.sh >> "$LOG_FILE" 2>&1 || true
        log "Wi-Fi portal start requested"
    fi

    # Asteapta stabilizarea proceselor stock, inclusiv mha_master.
    sleep 20

    # Watchdog-ul stock ar reporni mzigbee_agent si ar ocupa din nou UART-ul.
    for p in $(ps w 2>/dev/null | grep '[a]pp_monitor' | awk '{print $1}'); do
        kill -STOP "$p" 2>/dev/null || true
    done

    for p in $(ps w 2>/dev/null | grep '[m]zigbee_agent' | awk '{print $1}'); do
        kill -9 "$p" 2>/dev/null || true
    done
    for p in $(ps w 2>/dev/null | grep '[c]at /dev/ttyS1' | awk '{print $1}'); do
        kill -9 "$p" 2>/dev/null || true
    done

    stty -F /dev/ttyS1 115200 raw -echo 2>/dev/null || \
        stty 115200 raw -echo < /dev/ttyS1

    # Boot normal JN5189.
    echo out > /sys/class/gpio/gpio33/direction
    echo out > /sys/class/gpio/gpio18/direction
    echo 1 > /sys/class/gpio/gpio33/value
    echo 1 > /sys/class/gpio/gpio18/value
    sleep 1
    echo 0 > /sys/class/gpio/gpio18/value
    log "JN5189 Router reset released"

    # Bridge-ul butonului este optional si porneste numai daca este configurat.
    if [ -x /data/m1s_button/button_watch.sh ] && [ -s /data/m1s_button/m1s_button.conf ]; then
        if ! ps w 2>/dev/null | grep '[b]utton_watch.sh' >/dev/null 2>&1; then
            /data/m1s_button/button_watch.sh >> /tmp/m1s_button_console.log 2>&1 &
            log "Physical button bridge started"
        fi
    fi

    sleep 10
    printf '\245\000\000\000\245' > /dev/ttyS1
    log "Ring light OFF sent"
) &

exit 0
