#!/bin/sh
# Boot normal JN5189: GPIO33=1 si reset GPIO18 1 -> 0.

for p in $(ps w 2>/dev/null | grep '[m]zigbee_agent' | awk '{print $1}'); do
    kill -9 "$p" 2>/dev/null || true
done
for p in $(ps w 2>/dev/null | grep '[c]at /dev/ttyS1' | awk '{print $1}'); do
    kill -9 "$p" 2>/dev/null || true
done

stty -F /dev/ttyS1 115200 raw -echo 2>/dev/null || \
    stty 115200 raw -echo < /dev/ttyS1

echo out > /sys/class/gpio/gpio33/direction
echo out > /sys/class/gpio/gpio18/direction
echo 1 > /sys/class/gpio/gpio33/value
echo 1 > /sys/class/gpio/gpio18/value
sleep 1
echo 0 > /sys/class/gpio/gpio18/value
sleep 10

# RGB OFF: A5 00 00 00 A5
printf '\245\000\000\000\245' > /dev/ttyS1

echo "ROUTER_BOOT_SENT GPIO33=$(cat /sys/class/gpio/gpio33/value) GPIO18=$(cat /sys/class/gpio/gpio18/value)"
