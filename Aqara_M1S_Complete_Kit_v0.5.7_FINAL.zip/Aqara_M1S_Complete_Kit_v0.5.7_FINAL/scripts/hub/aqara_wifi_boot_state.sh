#!/bin/sh
# Verifica sau corecteaza proprietatile stock Aqara care aleg STA/AP la boot.
# Nu citeste si nu afiseaza SSID-ul, parola Wi-Fi sau tokenul MiIO.
# Utilizare:
#   ./aqara_wifi_boot_state.sh check
#   ./aqara_wifi_boot_state.sh fix

ACTION="${1:-check}"

read_state()
{
    CLOUD_PROVISIONED="$(getprop persist.app.cloud_provisioned 2>/dev/null)"
    HAP_PROVISIONED="$(getprop persist.app.hap_provisioned 2>/dev/null)"
    HAP_KEEPALIVE="$(getprop persist.app.hap_keepalive 2>/dev/null)"
    USER_PAIRED="$(getprop persist.app.user_paired 2>/dev/null)"
}

print_state()
{
    echo "cloud_provisioned=${CLOUD_PROVISIONED}"
    echo "hap_provisioned=${HAP_PROVISIONED}"
    echo "hap_keepalive=${HAP_KEEPALIVE}"
    echo "user_paired=${USER_PAIRED}"

    if [ "$CLOUD_PROVISIONED" = "true" ] || \
       [ "$HAP_PROVISIONED" = "true" ] || \
       [ "$HAP_KEEPALIVE" = "true" ]; then
        echo "BOOT_WIFI_SELECTION=STA_EXPECTED"
        return 0
    fi

    echo "BOOT_WIFI_SELECTION=AP_RISK"
    echo "ATENTIE: toate cele trei stari folosite de fw_manager.sh sunt inactive."
    return 1
}

case "$ACTION" in
    check)
        read_state
        print_state
        exit $?
        ;;
    fix)
        command -v setprop >/dev/null 2>&1 || {
            echo "EROARE: setprop nu este disponibil."
            exit 2
        }

        setprop persist.app.cloud_provisioned true
        setprop persist.app.hap_provisioned true
        setprop persist.app.hap_keepalive true
        setprop persist.app.user_paired true
        sync

        read_state
        print_state
        if [ "$CLOUD_PROVISIONED" = "true" ] && \
           [ "$HAP_PROVISIONED" = "true" ] && \
           [ "$HAP_KEEPALIVE" = "true" ] && \
           [ "$USER_PAIRED" = "true" ]; then
            echo "AQARA_WIFI_BOOT_STATE_FIXED"
            exit 0
        fi

        echo "EROARE: una sau mai multe proprietati nu au ramas setate pe true."
        exit 3
        ;;
    *)
        echo "Utilizare: $0 check|fix"
        exit 64
        ;;
esac
