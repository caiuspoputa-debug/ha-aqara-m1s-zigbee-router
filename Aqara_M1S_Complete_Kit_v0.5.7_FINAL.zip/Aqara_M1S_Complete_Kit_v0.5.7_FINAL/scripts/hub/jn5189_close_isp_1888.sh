#!/bin/sh
# Inchide listenerul temporar TCP-UART. Nu porneste automat firmware-ul JN5189.

PORT="${1:-1888}"
PID_FILE="/var/tmp/jn${PORT}_loop.pid"

if [ -f "$PID_FILE" ]; then
    loop_pid="$(cat "$PID_FILE" 2>/dev/null)"
    [ -n "$loop_pid" ] && kill -9 "$loop_pid" 2>/dev/null || true
    rm -f "$PID_FILE"
fi
for p in $(ps w 2>/dev/null | grep "[n]c -l -p $PORT" | awk '{print $1}'); do
    kill -9 "$p" 2>/dev/null || true
done
sleep 2

if netstat -lnt 2>/dev/null | grep -q ":$PORT"; then
    echo "EROARE: portul $PORT este inca deschis"
    exit 1
fi

echo "ISP_LISTENER_CLOSED port=$PORT"
