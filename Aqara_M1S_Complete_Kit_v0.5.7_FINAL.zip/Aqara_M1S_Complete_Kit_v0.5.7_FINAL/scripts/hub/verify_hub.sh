#!/bin/sh
# Raport de stare dupa conversie si dupa reboot. Nu modifica hubul.

get_ip()
{
    ifconfig wlan0 2>/dev/null |
        sed -n 's/.*inet addr:\([^ ]*\).*/\1/p' |
        head -n 1
}

echo "=== IDENTITATE ==="
echo "date=$(date)"
echo "ip=$(get_ip)"
echo "model=$(getprop ro.product.model 2>/dev/null)"
echo "temperature=$(getprop persist.sys.temperature 2>/dev/null)"

echo "=== SELECTIE STOCK WI-FI STA/AP (FARA CREDENTIALE) ==="
cloud_provisioned="$(getprop persist.app.cloud_provisioned 2>/dev/null)"
hap_provisioned="$(getprop persist.app.hap_provisioned 2>/dev/null)"
hap_keepalive="$(getprop persist.app.hap_keepalive 2>/dev/null)"
user_paired="$(getprop persist.app.user_paired 2>/dev/null)"
echo "cloud_provisioned=$cloud_provisioned"
echo "hap_provisioned=$hap_provisioned"
echo "hap_keepalive=$hap_keepalive"
echo "user_paired=$user_paired"
if [ "$cloud_provisioned" != "true" ] && \
   [ "$hap_provisioned" != "true" ] && \
   [ "$hap_keepalive" != "true" ]; then
    echo "WARNING AP_RISK: toate cele trei stari folosite de fw_manager.sh sunt inactive."
else
    echo "STA_EXPECTED"
fi

echo "=== PROCESE ==="
for pattern in '[t]elnetd' '[a]pp_monitor' '[m]zigbee_agent' '[m]ha_master' '[w]ifi_manager.sh' '[m]1s_wifi_portal_safe.sh' '[b]utton_watch.sh'; do
    echo "-- $pattern"
    ps w 2>/dev/null | grep "$pattern" || true
done

echo "=== GPIO ==="
echo "GPIO33=$(cat /sys/class/gpio/gpio33/value 2>/dev/null)"
echo "GPIO18=$(cat /sys/class/gpio/gpio18/value 2>/dev/null)"

echo "=== PORTURI ==="
netstat -lnt 2>/dev/null | grep -E ':(23|80|1886|1888|1889|8080|12346|12347|12348|12349)( |$)' || true

echo "=== FISIERE PERSISTENTE ==="
for f in /data/scripts/post_init.sh /data/m1s_wifi/wifi_manager.sh /data/m1s_button/button_watch.sh /data/m1s_button/m1s_button.conf; do
    if [ -e "$f" ]; then
        ls -l "$f"
    else
        echo "LIPSA $f"
    fi
done

echo "=== LOG POST_INIT ==="
tail -n 80 /tmp/post_init.log 2>/dev/null || true

echo "VERIFY_DONE"
