#!/bin/sh
# Instaleaza post_init.sh primit in acelasi director sau indicat ca argument.

SOURCE="${1:-./post_init.sh}"
DEST=/data/scripts/post_init.sh
STAMP="$(date +%Y%m%d_%H%M%S)"

[ -f "$SOURCE" ] || { echo "Lipseste $SOURCE"; exit 1; }
/bin/sh -n "$SOURCE" || { echo "Sintaxa invalida: $SOURCE"; exit 1; }
mkdir -p /data/scripts
[ -f "$DEST" ] && cp "$DEST" "$DEST.before_$STAMP"
cp "$SOURCE" "$DEST"
chown admin:0 "$DEST" 2>/dev/null || true
chmod 700 "$DEST"
sync
/bin/sh -n "$DEST" || exit 1
echo "POST_INIT_INSTALLED $DEST"
echo "Nu da reboot pana nu ai verificat backupul si continutul scriptului."
