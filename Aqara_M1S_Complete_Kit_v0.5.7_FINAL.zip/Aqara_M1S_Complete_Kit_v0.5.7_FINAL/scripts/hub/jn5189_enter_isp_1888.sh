#!/bin/sh
# Pune JN5189 in ISP si porneste un listener TCP-UART persistent pe 1888.
# Operatie temporara. Integrarea Home Assistant trebuie dezactivata inainte.

PORT="${1:-1888}"
PID_FILE="/var/tmp/jn${PORT}_loop.pid"
LOG_FILE="/var/tmp/jn${PORT}_loop.log"

stop_pidfile()
{
    if [ -f "$PID_FILE" ]; then
        old_pid="$(cat "$PID_FILE" 2>/dev/null)"
        [ -n "$old_pid" ] && kill -9 "$old_pid" 2>/dev/null || true
        rm -f "$PID_FILE"
    fi
}

stop_pidfile
for p in $(ps w 2>/dev/null | grep "[n]c -l -p $PORT" | awk '{print $1}'); do
    kill -9 "$p" 2>/dev/null || true
done
for p in $(ps w 2>/dev/null | grep '[a]pp_monitor' | awk '{print $1}'); do
    kill -STOP "$p" 2>/dev/null || true
done
for p in $(ps w 2>/dev/null | grep '[m]zigbee_agent' | awk '{print $1}'); do
    kill -9 "$p" 2>/dev/null || true
done
for p in $(ps w 2>/dev/null | grep '[c]at /dev/ttyS1' | awk '{print $1}'); do
    kill -9 "$p" 2>/dev/null || true
done

stty 115200 cs8 -parenb -cstopb cread clocal -crtscts \
  -ignbrk -brkint -ignpar -parmrk -inpck -istrip \
  -ixon -ixoff -icanon -echo min 1 time 0 < /dev/ttyS1

echo out > /sys/class/gpio/gpio33/direction
echo out > /sys/class/gpio/gpio18/direction
echo 0 > /sys/class/gpio/gpio33/value
echo 1 > /sys/class/gpio/gpio18/value
sleep 1
echo 0 > /sys/class/gpio/gpio18/value
sleep 1

(
    while :; do
        nc -l -p "$PORT" < /dev/ttyS1 > /dev/ttyS1
        sleep 1
    done
) >"$LOG_FILE" 2>&1 &
loop_pid=$!
echo "$loop_pid" > "$PID_FILE"
sleep 3

if netstat -lnt 2>/dev/null | grep -q ":$PORT"; then
    echo "ISP_LISTENER_OK port=$PORT pid=$loop_pid"
    echo "GPIO33=$(cat /sys/class/gpio/gpio33/value 2>/dev/null) GPIO18=$(cat /sys/class/gpio/gpio18/value 2>/dev/null)"
    exit 0
fi

echo "EROARE: listenerul $PORT nu asculta. Vezi $LOG_FILE"
exit 1
