#!/bin/sh
set -e

BASE=/data/m1s_button
PKG_DIR="$(CDPATH= cd "$(dirname "$0")" && pwd)"
PAYLOAD="$PKG_DIR/button_bridge_payload.tgz"
STAMP="$(date +%Y%m%d_%H%M%S)"
WORK="/tmp/m1s_button_install.$$"
BACKUP="/data/m1s_button_backup_$STAMP.tgz"

cleanup() { rm -rf "$WORK"; }
trap cleanup EXIT INT TERM

[ -f "$PAYLOAD" ] || { echo "Lipseste $PAYLOAD"; exit 1; }
mkdir -p "$WORK"
tar -xzf "$PAYLOAD" -C "$WORK"
for f in "$WORK"/data/m1s_button/*.sh; do /bin/sh -n "$f"; done

if [ -d "$BASE" ]; then
    (cd / && tar -czf "$BACKUP" data/m1s_button)
    tar -tzf "$BACKUP" >/dev/null
fi

mkdir -p "$BASE"
cp "$WORK/data/m1s_button/m1s_mqtt_publish.sh" "$BASE/"
cp "$WORK/data/m1s_button/button_watch.sh" "$BASE/"
cp "$WORK/data/m1s_button/m1s_button.conf.example" "$BASE/"
[ -e "$BASE/mqtt_username" ] || cp "$WORK/data/m1s_button/mqtt_username" "$BASE/"
[ -e "$BASE/mqtt_password" ] || cp "$WORK/data/m1s_button/mqtt_password" "$BASE/"
chmod 700 "$BASE"/*.sh
chmod 600 "$BASE/mqtt_username" "$BASE/mqtt_password"
chown -R admin:0 "$BASE" 2>/dev/null || true
sync

echo "BUTTON_BRIDGE_FILES_INSTALLED"
echo "Urmatorul pas: creeaza $BASE/m1s_button.conf si completeaza local credentialele MQTT."
echo "Pachetul nu contine broker, username sau parola."
[ -f "$BACKUP" ] && echo "Backup: $BACKUP"
