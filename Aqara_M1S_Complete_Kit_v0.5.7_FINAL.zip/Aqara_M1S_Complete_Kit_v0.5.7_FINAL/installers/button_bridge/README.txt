Aqara M1S physical button -> MQTT bridge

Pachetul NU contine IP-ul brokerului, username sau parola.
Dupa instalare:
1. copiaza /data/m1s_button/m1s_button.conf.example ca m1s_button.conf;
2. completeaza BROKER_HOST si portul;
3. scrie username/parola cu printf in fisierele mqtt_username/mqtt_password;
4. chmod 600 pe configuratie si credentiale;
5. testeaza: /data/m1s_button/m1s_mqtt_publish.sh click;
6. porneste watcherul sau reporneste hubul dupa instalarea post_init.sh.

Topic: m1s/<ultimul_octet_al_IP-ului_hubului>/button/action
Actiuni: click, double_click, triple_click, quadruple_click, five_click, hold
