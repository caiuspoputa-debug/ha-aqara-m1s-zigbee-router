#!/bin/sh
set -e

BASE=/data/m1s_wifi
SCRIPTS=/data/scripts
PKG_DIR="$(CDPATH= cd "$(dirname "$0")" && pwd)"
PAYLOAD="$PKG_DIR/payload_clean.tgz"
STAMP="$(date +%Y%m%d_%H%M%S)"
WORK="/tmp/m1s_wifi_install.$$"
OLD_BASE="/data/m1s_wifi.before_$STAMP"
BACKUP="/data/m1s_wifi_backup_$STAMP.tgz"
LOG="/tmp/m1s_wifi_install_$STAMP.log"
START1="$SCRIPTS/wifi_manager_start.sh"
START2="$SCRIPTS/wifi_portal_start.sh"
OLD_START1="/data/wifi_manager_start.before_$STAMP.sh"
OLD_START2="/data/wifi_portal_start.before_$STAMP.sh"
MUTATION_STARTED=0
INSTALL_OK=0
HAD_BASE=0
HAD_START1=0
HAD_START2=0
PRESERVE_ACTIONS=0
CAPTURED_SSID=""
CAPTURED_PASS=""

say() { echo "$*"; echo "$*" >> "$LOG"; }
fail() { say "EROARE: $*"; exit 1; }

capture_runtime_wifi()
{
    if [ -s "$BASE/safe/ssid" ]; then
        CAPTURED_SSID="$(cat "$BASE/safe/ssid" 2>/dev/null)"
    else
        CAPTURED_SSID="$(getprop persist.app.wifi_ssid 2>/dev/null)"
    fi
    if [ -s "$BASE/safe/pass" ]; then
        CAPTURED_PASS="$(cat "$BASE/safe/pass" 2>/dev/null)"
    else
        CAPTURED_PASS="$(getprop persist.app.wifi_passphrase 2>/dev/null)"
    fi
}

stop_project()
{
    for pattern in '[w]ifi_manager.sh' '[m]1s_wifi_portal_safe.sh' '[a]p_watchdog.sh'; do
        for pid in $(ps w 2>/dev/null | grep "$pattern" | awk '{print $1}'); do
            kill "$pid" 2>/dev/null || true
        done
    done
    sleep 1
}

restore_old()
{
    say "=== ROLLBACK AUTOMAT ==="
    stop_project
    rm -rf "$BASE"
    rm -f "$START1" "$START2"
    [ "$HAD_BASE" -eq 1 ] && [ -d "$OLD_BASE" ] && mv "$OLD_BASE" "$BASE"
    [ "$HAD_START1" -eq 1 ] && [ -f "$OLD_START1" ] && mv "$OLD_START1" "$START1"
    [ "$HAD_START2" -eq 1 ] && [ -f "$OLD_START2" ] && mv "$OLD_START2" "$START2"
    sync
    [ -x "$START1" ] && "$START1" >> "$LOG" 2>&1 || true
    [ -x "$START2" ] && "$START2" >> "$LOG" 2>&1 || true
    say "ROLLBACK_TERMINAT"
}

cleanup()
{
    rc=$?
    rm -rf "$WORK"
    if [ "$rc" -ne 0 ] && [ "$MUTATION_STARTED" -eq 1 ] && [ "$INSTALL_OK" -eq 0 ]; then
        restore_old
    fi
    exit "$rc"
}
trap cleanup EXIT INT TERM

[ -f "$PAYLOAD" ] || fail "lipseste payload_clean.tgz"
mkdir -p "$WORK" "$SCRIPTS"

say "=== VALIDARE PACHET SANITIZAT ==="
tar -tzf "$PAYLOAD" > "$WORK/list.txt" 2>> "$LOG" || fail "arhiva nu poate fi citita"
for required in \
    data/m1s_wifi/wifi_manager.sh \
    data/m1s_wifi/m1s_wifi_portal_safe.sh \
    data/m1s_wifi/wifi_apply_candidate.sh \
    data/m1s_wifi/restore_sta.sh \
    data/m1s_wifi/ap_watchdog.sh \
    data/m1s_wifi/candidate_failed_to_ap.sh \
    data/scripts/wifi_manager_start.sh \
    data/scripts/wifi_portal_start.sh
do
    grep -x "$required" "$WORK/list.txt" >/dev/null 2>&1 || fail "lipseste $required"
done

tar -xzf "$PAYLOAD" -C "$WORK" 2>> "$LOG" || fail "extragerea a esuat"
for script in "$WORK"/data/m1s_wifi/*.sh "$WORK"/data/scripts/*.sh; do
    [ -f "$script" ] || continue
    /bin/sh -n "$script" 2>> "$LOG" || fail "sintaxa invalida: $script"
done

[ -d "$BASE" ] && HAD_BASE=1
[ -f "$START1" ] && HAD_START1=1
[ -f "$START2" ] && HAD_START2=1
[ -e "$BASE/actions_enabled" ] && PRESERVE_ACTIONS=1
capture_runtime_wifi
[ -n "$CAPTURED_SSID" ] || fail "SSID-ul curent nu poate fi citit; instalarea se opreste fara modificari"
[ -n "$CAPTURED_PASS" ] || fail "parola Wi-Fi curenta nu poate fi citita; instalarea se opreste fara modificari"

say "=== BACKUP SIGUR ==="
BACKUP_LIST=""
[ "$HAD_BASE" -eq 1 ] && BACKUP_LIST="$BACKUP_LIST data/m1s_wifi"
[ "$HAD_START1" -eq 1 ] && BACKUP_LIST="$BACKUP_LIST data/scripts/wifi_manager_start.sh"
[ "$HAD_START2" -eq 1 ] && BACKUP_LIST="$BACKUP_LIST data/scripts/wifi_portal_start.sh"
if [ -n "$BACKUP_LIST" ]; then
    (cd / && tar -czf "$BACKUP" $BACKUP_LIST) 2>> "$LOG" || fail "backup esuat; nimic modificat"
    tar -tzf "$BACKUP" >/dev/null 2>> "$LOG" || fail "backup neverificabil; nimic modificat"
    say "Backup creat: $BACKUP"
else
    say "Nu exista instalare anterioara; backupul proiectului este omis."
fi

stop_project
[ ! -e "$OLD_BASE" ] || fail "exista deja $OLD_BASE"
MUTATION_STARTED=1
[ "$HAD_BASE" -eq 1 ] && mv "$BASE" "$OLD_BASE"
[ "$HAD_START1" -eq 1 ] && mv "$START1" "$OLD_START1"
[ "$HAD_START2" -eq 1 ] && mv "$START2" "$OLD_START2"

mkdir -p "$BASE" "$SCRIPTS"
cp -Rp "$WORK/data/m1s_wifi/." "$BASE/" || fail "copiere m1s_wifi esuata"
cp -p "$WORK/data/scripts/wifi_manager_start.sh" "$START1" || fail "copiere start manager esuata"
cp -p "$WORK/data/scripts/wifi_portal_start.sh" "$START2" || fail "copiere start portal esuata"

printf '%s' "$CAPTURED_SSID" > "$BASE/safe/ssid"
printf '%s' "$CAPTURED_PASS" > "$BASE/safe/pass"
chown -R admin:0 "$BASE" 2>/dev/null || true
chown admin:0 "$START1" "$START2" 2>/dev/null || true
chmod 700 "$BASE"/*.sh "$START1" "$START2"
chmod 600 "$BASE/safe/ssid" "$BASE/safe/pass"
if [ "$PRESERVE_ACTIONS" -eq 1 ]; then
    : > "$BASE/actions_enabled"; chmod 600 "$BASE/actions_enabled"
else
    rm -f "$BASE/actions_enabled"
fi
sync

"$START1" >> "$LOG" 2>&1 || fail "manager start esuat"
"$START2" >> "$LOG" 2>&1 || fail "portal start esuat"
sleep 2
ps w 2>/dev/null | grep '[w]ifi_manager.sh' >/dev/null 2>&1 || fail "managerul nu ruleaza"
ps w 2>/dev/null | grep '[m]1s_wifi_portal_safe.sh' >/dev/null 2>&1 || fail "portalul nu ruleaza"

INSTALL_OK=1
rm -rf "$OLD_BASE"
rm -f "$OLD_START1" "$OLD_START2"
sync
say "=== INSTALARE REUSITA ==="
say "Pachetul nu a continut SSID/parola; valorile au fost preluate local de pe hub."
say "Actiunile AP automate sunt active numai daca exista /data/m1s_wifi/actions_enabled."
say "Log: $LOG"
echo WIFI_RECOVERY_INSTALL_OK
