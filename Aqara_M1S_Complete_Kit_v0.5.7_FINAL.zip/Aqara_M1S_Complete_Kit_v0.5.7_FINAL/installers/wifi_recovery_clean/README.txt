Aqara M1S Wi-Fi Recovery — pachet curat, fara SSID sau parole incluse

- installerul preia SSID/parola curente direct de pe hub inainte de inlocuire;
- fisierele payload/data/m1s_wifi/safe/ssid si safe/pass sunt intentionat goale;
- actiunile automate sunt in modul simulare pana la crearea fisierului:
    /data/m1s_wifi/actions_enabled
- portalul asculta pe portul 8080;
- parola din formular este mascata;
- nu sunt incluse scripturile istorice *.before_* sau credentiale previous_*.

Rezultat asteptat: WIFI_RECOVERY_INSTALL_OK

HOME ASSISTANT v0.5.7
---------------------
After this module is installed and validated, the integration menu exposes:
  Configure -> Change Wi-Fi network
The integration never stores the entered Wi-Fi password in config-entry data or options.
The candidate is promoted only after wifi_apply_candidate.sh obtains a fresh IPv4 address.
Reserve the same hub IP for its Wi-Fi MAC on the destination network whenever possible.
