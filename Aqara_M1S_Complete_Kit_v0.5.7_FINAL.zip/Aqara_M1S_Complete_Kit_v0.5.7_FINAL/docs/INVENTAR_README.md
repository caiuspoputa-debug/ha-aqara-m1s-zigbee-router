# Inventar README/CHANGELOG din arhiva originală

Generat direct din `de facut readme ok.zip`, fără folderele temporare ale analizei.

- README-uri după nume: **68**
- CHANGELOG-uri: **38**
- Total inventariat: **106**
- Conținuturi unice după SHA256: **86**
- Copii redundante: **20**

## Toate fișierele

| # | Cale | Bytes | SHA256 (primele 16) | Grup |
|---:|---|---:|---|---:|
| 1 | `Aqara_M1S_Router_RGB_Lux_Firmware/README_TEST_RO 0.md` | 1890 | `b7a717f33bd1f829` | 1 |
| 2 | `Aqara_M1S_Router_RGB_Lux_PIO19_Fix/README_TEST_RO 1.md` | 1999 | `cd1550363e9d6ca3` | 2 |
| 3 | `aqara_m1s_zigbee_router_v0_1_0/CHANGELOG.md` | 873 | `4980bfb938215a71` | 3 |
| 4 | `aqara_m1s_zigbee_router_v0_1_0/README.md` | 2380 | `7c684faa7a4b0017` | 4 |
| 5 | `aqara_m1s_zigbee_router_v0_1_3/CHANGELOG.md` | 1488 | `80440c4b13b90f02` | 5 |
| 6 | `aqara_m1s_zigbee_router_v0_1_3/README.md` | 2557 | `a70cae44dce67f3f` | 6 |
| 7 | `aqara_m1s_zigbee_router_v0_1_4/aqara_m1s_zigbee_router_v0_1_4/CHANGELOG.md` | 2403 | `5e3f3082a0014501` | 7 |
| 8 | `aqara_m1s_zigbee_router_v0_1_4/aqara_m1s_zigbee_router_v0_1_4/README.md` | 4073 | `224b20ba24d78521` | 8 |
| 9 | `aqara_m1s_zigbee_router_v0_1_5/aqara_m1s_zigbee_router_v0_1_5/CHANGELOG.md` | 3002 | `cc3b54c8ddb30491` | 9 |
| 10 | `aqara_m1s_zigbee_router_v0_1_7_final (1)/aqara_m1s_zigbee_router_v0_1_7_final/CHANGELOG.md` | 4155 | `f0bc7f2cf4a5a5ae` | 10 |
| 11 | `aqara_m1s_zigbee_router_v0_1_7_final (1)/aqara_m1s_zigbee_router_v0_1_7_final/README.md` | 4607 | `6f0600091cc25d9c` | 11 |
| 12 | `aqara_m1s_zigbee_router_v0_1_7_final/aqara_m1s_zigbee_router_v0_1_7_final/CHANGELOG.md` | 4155 | `f0bc7f2cf4a5a5ae` | 10 |
| 13 | `aqara_m1s_zigbee_router_v0_1_7_final/aqara_m1s_zigbee_router_v0_1_7_final/README.md` | 4607 | `6f0600091cc25d9c` | 11 |
| 14 | `aqara_m1s_zigbee_router_v0_1_8_final/aqara_m1s_zigbee_router_v0_1_8_final/CHANGELOG.md` | 4496 | `4ffa7f1361360fdb` | 12 |
| 15 | `aqara_m1s_zigbee_router_v0_1_8_final/aqara_m1s_zigbee_router_v0_1_8_final/README.md` | 4722 | `46711992374eb615` | 13 |
| 16 | `aqara_m1s_zigbee_router_v0_1_9_final/aqara_m1s_zigbee_router_v0_1_9_final/CHANGELOG.md` | 4962 | `91c57f5ba34d9145` | 14 |
| 17 | `aqara_m1s_zigbee_router_v0_1_9_final/aqara_m1s_zigbee_router_v0_1_9_final/README.md` | 4694 | `8969265eb3dd0535` | 15 |
| 18 | `aqara_m1s_zigbee_router_v0_2_0/aqara_m1s_zigbee_router_v0_2_0/CHANGELOG.md` | 5435 | `b9a3bb04161e413a` | 16 |
| 19 | `aqara_m1s_zigbee_router_v0_2_0/aqara_m1s_zigbee_router_v0_2_0/README.md` | 4770 | `a3269757e15d872f` | 17 |
| 20 | `aqara_m1s_zigbee_router_v0_2_1_repository_source_10s_off/aqara_m1s_zigbee_router_v0_2_1_rejoin/CHANGELOG.md` | 6106 | `02088d19492b001c` | 18 |
| 21 | `aqara_m1s_zigbee_router_v0_2_1_repository_source_10s_off/aqara_m1s_zigbee_router_v0_2_1_rejoin/README.md` | 16982 | `ebfc16c9ee1f0f93` | 19 |
| 22 | `aqara_m1s_zigbee_router_v0_2_1_repository_source_10s_off/aqara_m1s_zigbee_router_v0_2_1_rejoin/README_RO.md` | 17933 | `1b02b52b7cea5c81` | 20 |
| 23 | `aqara_m1s_zigbee_router_v0_2_2/aqara_m1s_zigbee_router_v0_2_2/CHANGELOG.md` | 6909 | `01df721e85e7dcf3` | 21 |
| 24 | `aqara_m1s_zigbee_router_v0_2_2/aqara_m1s_zigbee_router_v0_2_2/README.md` | 18976 | `cdd12db8ec60ffdc` | 22 |
| 25 | `aqara_m1s_zigbee_router_v0_2_2/aqara_m1s_zigbee_router_v0_2_2/README_RO.md` | 19673 | `bc57912fdae0dbc6` | 23 |
| 26 | `aqara_m1s_zigbee_router_v0_2_3_reload_on_finish/CHANGELOG.md` | 7310 | `bfdfeb14eb48a2d7` | 24 |
| 27 | `aqara_m1s_zigbee_router_v0_2_3_reload_on_finish/README.md` | 19149 | `63c5f4977a2fc573` | 25 |
| 28 | `aqara_m1s_zigbee_router_v0_2_3_reload_on_finish/README_RO.md` | 19673 | `408db5866dca36e0` | 26 |
| 29 | `aqara_m1s_zigbee_router_v0_2_4_bilingual_safe_finish/CHANGELOG.md` | 8105 | `558c2f86d447b109` | 27 |
| 30 | `aqara_m1s_zigbee_router_v0_2_4_bilingual_safe_finish/README.md` | 21478 | `29a41735f6b55e29` | 28 |
| 31 | `aqara_m1s_zigbee_router_v0_2_4_bilingual_safe_finish/README_RO.md` | 22561 | `cd3654b5d1c02fb5` | 29 |
| 32 | `aqara_m1s_zigbee_router_v0_2_5/CHANGELOG.md` | 8360 | `819c3e663aa8f38d` | 30 |
| 33 | `aqara_m1s_zigbee_router_v0_2_5/README.md` | 21659 | `3626660a9c93ff3f` | 31 |
| 34 | `aqara_m1s_zigbee_router_v0_2_5/README_RO.md` | 22769 | `e13f01c0730e87dd` | 32 |
| 35 | `aqara_m1s_zigbee_router_v0_2_6/CHANGELOG.md` | 8445 | `b00fcd723647a9b6` | 33 |
| 36 | `aqara_m1s_zigbee_router_v0_2_6/README.md` | 21785 | `ac5f23af0ecbaed9` | 34 |
| 37 | `aqara_m1s_zigbee_router_v0_2_6/README_RO.md` | 22901 | `2155eaeb25f7ea63` | 35 |
| 38 | `aqara_m1s_zigbee_router_v0_2_7/CHANGELOG.md` | 8785 | `a21c1e128e9bcc33` | 36 |
| 39 | `aqara_m1s_zigbee_router_v0_2_7/README.md` | 21785 | `56ab678091e2790b` | 37 |
| 40 | `aqara_m1s_zigbee_router_v0_2_7/README_RO.md` | 22901 | `2d15d4ef63b5b6de` | 38 |
| 41 | `aqara_m1s_zigbee_router_v0_2_9_doua_slidere_volum/CHANGELOG.md` | 9209 | `66a3c961f39fed9a` | 39 |
| 42 | `aqara_m1s_zigbee_router_v0_2_9_doua_slidere_volum/README.md` | 22291 | `48a7cd8091a3429c` | 40 |
| 43 | `aqara_m1s_zigbee_router_v0_2_9_doua_slidere_volum/README_RO.md` | 23474 | `d30485a268faeb38` | 41 |
| 44 | `aqara_m1s_zigbee_router_v0_3_0/CHANGELOG.md` | 9744 | `355d6a25928a9a76` | 42 |
| 45 | `aqara_m1s_zigbee_router_v0_3_0/README.md` | 22783 | `cde025d6f495f7f5` | 43 |
| 46 | `aqara_m1s_zigbee_router_v0_3_0/README_RO.md` | 23993 | `7d1faeedcd6cd677` | 44 |
| 47 | `aqara_m1s_zigbee_router_v0_3_1/CHANGELOG.md` | 10283 | `eed2f1f3b7145239` | 45 |
| 48 | `aqara_m1s_zigbee_router_v0_3_1/README.md` | 23243 | `ac2df932b1f09d70` | 46 |
| 49 | `aqara_m1s_zigbee_router_v0_3_1/README_RO.md` | 24469 | `95b064635fa9769a` | 47 |
| 50 | `aqara_m1s_zigbee_router_v0_3_2/CHANGELOG.md` | 9744 | `355d6a25928a9a76` | 42 |
| 51 | `aqara_m1s_zigbee_router_v0_3_2/README.md` | 22691 | `312c716664891adf` | 48 |
| 52 | `aqara_m1s_zigbee_router_v0_3_2/README_RO.md` | 23570 | `166da0bf946e2655` | 49 |
| 53 | `aqara_m1s_zigbee_router_v0_3_3/CHANGELOG.md` | 10847 | `dd0e65ee04643ef5` | 50 |
| 54 | `aqara_m1s_zigbee_router_v0_3_3/README.md` | 23254 | `b804530bab624a8c` | 51 |
| 55 | `aqara_m1s_zigbee_router_v0_3_3/README_RO.md` | 24497 | `71ad12bb7c870b18` | 52 |
| 56 | `aqara_m1s_zigbee_router_v0_3_4/CHANGELOG.md` | 11428 | `eed93591ac65ff33` | 53 |
| 57 | `aqara_m1s_zigbee_router_v0_3_4/README.md` | 23796 | `3d17d6f3bfdbb987` | 54 |
| 58 | `aqara_m1s_zigbee_router_v0_3_4/README_RO.md` | 25105 | `ae7e00040b7148f8` | 55 |
| 59 | `aqara_m1s_zigbee_router_v0_3_5/CHANGELOG.md` | 11909 | `7266ddcbd410a57a` | 56 |
| 60 | `aqara_m1s_zigbee_router_v0_3_5/README.md` | 23796 | `3d17d6f3bfdbb987` | 54 |
| 61 | `aqara_m1s_zigbee_router_v0_3_5/README_RO.md` | 25105 | `ae7e00040b7148f8` | 55 |
| 62 | `aqara_m1s_zigbee_router_v0_3_6/CHANGELOG.md` | 12244 | `1ecdda872265068d` | 57 |
| 63 | `aqara_m1s_zigbee_router_v0_3_6/README.md` | 23796 | `3d17d6f3bfdbb987` | 54 |
| 64 | `aqara_m1s_zigbee_router_v0_3_6/README_RO.md` | 25105 | `ae7e00040b7148f8` | 55 |
| 65 | `aqara_m1s_zigbee_router_v0_3_7/CHANGELOG.md` | 13012 | `f878396e5f8541d6` | 58 |
| 66 | `aqara_m1s_zigbee_router_v0_3_7/README.md` | 23796 | `3d17d6f3bfdbb987` | 54 |
| 67 | `aqara_m1s_zigbee_router_v0_3_7/README_RO.md` | 25105 | `ae7e00040b7148f8` | 55 |
| 68 | `ha-aqara-m1s-zigbee-router-v0.4.0-test/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md` | 1371 | `fb6b1061bbad95ae` | 59 |
| 69 | `ha-aqara-m1s-zigbee-router-v0.4.0-test/ha-aqara-m1s-zigbee-router-main/README.md` | 27239 | `99320c403732fe46` | 60 |
| 70 | `ha-aqara-m1s-zigbee-router-v0.4.0-test/ha-aqara-m1s-zigbee-router-main/README_RO.md` | 28577 | `f90e6c2ccaa96ce0` | 61 |
| 71 | `ha-aqara-m1s-zigbee-router-v0.4.1-test/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md` | 1816 | `3850e1d3e36b9ec9` | 62 |
| 72 | `ha-aqara-m1s-zigbee-router-v0.4.1-test/ha-aqara-m1s-zigbee-router-main/README.md` | 27239 | `99320c403732fe46` | 60 |
| 73 | `ha-aqara-m1s-zigbee-router-v0.4.1-test/ha-aqara-m1s-zigbee-router-main/README_RO.md` | 28577 | `f90e6c2ccaa96ce0` | 61 |
| 74 | `ha-aqara-m1s-zigbee-router-v0.4.1-test/m1s_v041/CHANGELOG.md` | 1816 | `3850e1d3e36b9ec9` | 62 |
| 75 | `ha-aqara-m1s-zigbee-router-v0.4.1-test/m1s_v041/README.md` | 27239 | `99320c403732fe46` | 60 |
| 76 | `ha-aqara-m1s-zigbee-router-v0.4.1-test/m1s_v041/README_RO.md` | 28577 | `f90e6c2ccaa96ce0` | 61 |
| 77 | `ha-aqara-m1s-zigbee-router-v0.4.2/m1s_v041/CHANGELOG.md` | 2240 | `cf98e3dee3883053` | 63 |
| 78 | `ha-aqara-m1s-zigbee-router-v0.4.2/m1s_v041/README.md` | 27657 | `ba9db148e1a3fc78` | 64 |
| 79 | `ha-aqara-m1s-zigbee-router-v0.4.2/m1s_v041/README_RO.md` | 28577 | `f90e6c2ccaa96ce0` | 61 |
| 80 | `ha-aqara-m1s-zigbee-router-v0.4.3-corrected/m1s043/CHANGELOG.md` | 2240 | `7059c8f826553dd3` | 65 |
| 81 | `ha-aqara-m1s-zigbee-router-v0.4.3-corrected/m1s043/README.md` | 27657 | `25bb91a13e421276` | 66 |
| 82 | `ha-aqara-m1s-zigbee-router-v0.4.3-corrected/m1s043/README_RO.md` | 28577 | `f90e6c2ccaa96ce0` | 61 |
| 83 | `ha-aqara-m1s-zigbee-router-v0.4.3/m1s043/CHANGELOG.md` | 2240 | `7059c8f826553dd3` | 65 |
| 84 | `ha-aqara-m1s-zigbee-router-v0.4.3/m1s043/README.md` | 27657 | `25bb91a13e421276` | 66 |
| 85 | `ha-aqara-m1s-zigbee-router-v0.4.3/m1s043/README_RO.md` | 28577 | `f90e6c2ccaa96ce0` | 61 |
| 86 | `ha-aqara-m1s-zigbee-router-v0.5.0-timestamp-sync-test/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md` | 1580 | `c94027657559b5bd` | 67 |
| 87 | `ha-aqara-m1s-zigbee-router-v0.5.0-timestamp-sync-test/ha-aqara-m1s-zigbee-router-main/README.md` | 28900 | `b26cd6f52863efe9` | 68 |
| 88 | `ha-aqara-m1s-zigbee-router-v0.5.0-timestamp-sync-test/ha-aqara-m1s-zigbee-router-main/README_RO.md` | 30381 | `be874c669d1af7e1` | 69 |
| 89 | `ha-aqara-m1s-zigbee-router-v0.5.1-platform-fix/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md` | 1730 | `475f48f4ff9e5db9` | 70 |
| 90 | `ha-aqara-m1s-zigbee-router-v0.5.1-platform-fix/ha-aqara-m1s-zigbee-router-main/README.md` | 28900 | `034678649bfb6c6a` | 71 |
| 91 | `ha-aqara-m1s-zigbee-router-v0.5.1-platform-fix/ha-aqara-m1s-zigbee-router-main/README_RO.md` | 30381 | `be874c669d1af7e1` | 69 |
| 92 | `ha-aqara-m1s-zigbee-router-v0.5.2-volume-0.2-percent/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md` | 2178 | `fa06b4718fe0ba1b` | 72 |
| 93 | `ha-aqara-m1s-zigbee-router-v0.5.2-volume-0.2-percent/ha-aqara-m1s-zigbee-router-main/README.md` | 29035 | `a8fdb0e706b6cc4d` | 73 |
| 94 | `ha-aqara-m1s-zigbee-router-v0.5.2-volume-0.2-percent/ha-aqara-m1s-zigbee-router-main/README_RO.md` | 30549 | `69fcdf85e3da8dd5` | 74 |
| 95 | `ha-aqara-m1s-zigbee-router-v0.5.3-full-group-resync/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md` | 2773 | `aef9a50a655c9766` | 75 |
| 96 | `ha-aqara-m1s-zigbee-router-v0.5.3-full-group-resync/ha-aqara-m1s-zigbee-router-main/README.md` | 29150 | `5d7ecfd9c33e689f` | 76 |
| 97 | `ha-aqara-m1s-zigbee-router-v0.5.3-full-group-resync/ha-aqara-m1s-zigbee-router-main/README_RO.md` | 30684 | `4b16b97e27cdcbdc` | 77 |
| 98 | `ha-aqara-m1s-zigbee-router-v0.5.4-group-volume-final-release/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md` | 3243 | `e5d2f66fc8c7303f` | 78 |
| 99 | `ha-aqara-m1s-zigbee-router-v0.5.4-group-volume-final-release/ha-aqara-m1s-zigbee-router-main/README.md` | 29465 | `21f25fc31ef0b41e` | 79 |
| 100 | `ha-aqara-m1s-zigbee-router-v0.5.4-group-volume-final-release/ha-aqara-m1s-zigbee-router-main/README_RO.md` | 31054 | `a144b17f2ef750ad` | 80 |
| 101 | `ha-aqara-m1s-zigbee-router-v0.5.5-live-group-volume-no-restart/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md` | 3784 | `b0c8eecc5016c846` | 81 |
| 102 | `ha-aqara-m1s-zigbee-router-v0.5.5-live-group-volume-no-restart/ha-aqara-m1s-zigbee-router-main/README.md` | 29872 | `08548bf337101e2c` | 82 |
| 103 | `ha-aqara-m1s-zigbee-router-v0.5.5-live-group-volume-no-restart/ha-aqara-m1s-zigbee-router-main/README_RO.md` | 31524 | `70d2490c260c4c15` | 83 |
| 104 | `ha-aqara-m1s-zigbee-router-v0.5.6-live-individual-volume-priority/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md` | 4609 | `9fa35a366f721c21` | 84 |
| 105 | `ha-aqara-m1s-zigbee-router-v0.5.6-live-individual-volume-priority/ha-aqara-m1s-zigbee-router-main/README.md` | 30417 | `2d19f4d59e593d23` | 85 |
| 106 | `ha-aqara-m1s-zigbee-router-v0.5.6-live-individual-volume-priority/ha-aqara-m1s-zigbee-router-main/README_RO.md` | 32141 | `d18c4d50739e1b85` | 86 |

## Grupuri duplicate

### Grup 61 — 6 copii — `f90e6c2ccaa96ce018dc93a1e95608da59a4358b3dd9b3cb0717184f14b44142`

- `ha-aqara-m1s-zigbee-router-v0.4.0-test/ha-aqara-m1s-zigbee-router-main/README_RO.md`
- `ha-aqara-m1s-zigbee-router-v0.4.1-test/ha-aqara-m1s-zigbee-router-main/README_RO.md`
- `ha-aqara-m1s-zigbee-router-v0.4.1-test/m1s_v041/README_RO.md`
- `ha-aqara-m1s-zigbee-router-v0.4.2/m1s_v041/README_RO.md`
- `ha-aqara-m1s-zigbee-router-v0.4.3-corrected/m1s043/README_RO.md`
- `ha-aqara-m1s-zigbee-router-v0.4.3/m1s043/README_RO.md`

### Grup 54 — 4 copii — `3d17d6f3bfdbb9872a2cc102ecd41bad3e19c56f8ec5dd67078473518f83fc24`

- `aqara_m1s_zigbee_router_v0_3_4/README.md`
- `aqara_m1s_zigbee_router_v0_3_5/README.md`
- `aqara_m1s_zigbee_router_v0_3_6/README.md`
- `aqara_m1s_zigbee_router_v0_3_7/README.md`

### Grup 55 — 4 copii — `ae7e00040b7148f8f36a4f0c6afa4b3dab69078419cc6c73eb612985d0d16564`

- `aqara_m1s_zigbee_router_v0_3_4/README_RO.md`
- `aqara_m1s_zigbee_router_v0_3_5/README_RO.md`
- `aqara_m1s_zigbee_router_v0_3_6/README_RO.md`
- `aqara_m1s_zigbee_router_v0_3_7/README_RO.md`

### Grup 60 — 3 copii — `99320c403732fe463b283f3fcb63e5d4a90bc6536452f7c7ed0cc9334075c894`

- `ha-aqara-m1s-zigbee-router-v0.4.0-test/ha-aqara-m1s-zigbee-router-main/README.md`
- `ha-aqara-m1s-zigbee-router-v0.4.1-test/ha-aqara-m1s-zigbee-router-main/README.md`
- `ha-aqara-m1s-zigbee-router-v0.4.1-test/m1s_v041/README.md`

### Grup 10 — 2 copii — `f0bc7f2cf4a5a5ae0590bf5d43ca409f7d42ac6d97dbb733b79d23380f7fcb70`

- `aqara_m1s_zigbee_router_v0_1_7_final (1)/aqara_m1s_zigbee_router_v0_1_7_final/CHANGELOG.md`
- `aqara_m1s_zigbee_router_v0_1_7_final/aqara_m1s_zigbee_router_v0_1_7_final/CHANGELOG.md`

### Grup 11 — 2 copii — `6f0600091cc25d9c79e9e82fe8173e85d333fd93b5e8d389e2efb5e8fb16028c`

- `aqara_m1s_zigbee_router_v0_1_7_final (1)/aqara_m1s_zigbee_router_v0_1_7_final/README.md`
- `aqara_m1s_zigbee_router_v0_1_7_final/aqara_m1s_zigbee_router_v0_1_7_final/README.md`

### Grup 42 — 2 copii — `355d6a25928a9a765159a6a8ac096821adf82fba69abe6517334df38e4547d4f`

- `aqara_m1s_zigbee_router_v0_3_0/CHANGELOG.md`
- `aqara_m1s_zigbee_router_v0_3_2/CHANGELOG.md`

### Grup 62 — 2 copii — `3850e1d3e36b9ec96b7b3bf415db664e07f57c16a5c3a0eb70134c613ef6dadb`

- `ha-aqara-m1s-zigbee-router-v0.4.1-test/ha-aqara-m1s-zigbee-router-main/CHANGELOG.md`
- `ha-aqara-m1s-zigbee-router-v0.4.1-test/m1s_v041/CHANGELOG.md`

### Grup 65 — 2 copii — `7059c8f826553dd35ff8b6301c300c5b1d76b692802fe74448c4f3795e3dcf5b`

- `ha-aqara-m1s-zigbee-router-v0.4.3-corrected/m1s043/CHANGELOG.md`
- `ha-aqara-m1s-zigbee-router-v0.4.3/m1s043/CHANGELOG.md`

### Grup 66 — 2 copii — `25bb91a13e4212766c7722e330344807ebbc96ea57ecf2fa219631e82e81e0ba`

- `ha-aqara-m1s-zigbee-router-v0.4.3-corrected/m1s043/README.md`
- `ha-aqara-m1s-zigbee-router-v0.4.3/m1s043/README.md`

### Grup 69 — 2 copii — `be874c669d1af7e15825524951a93534d8afff93ace95d3a85ed42516f13864f`

- `ha-aqara-m1s-zigbee-router-v0.5.0-timestamp-sync-test/ha-aqara-m1s-zigbee-router-main/README_RO.md`
- `ha-aqara-m1s-zigbee-router-v0.5.1-platform-fix/ha-aqara-m1s-zigbee-router-main/README_RO.md`

