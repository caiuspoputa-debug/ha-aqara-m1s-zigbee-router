# Audit README și scripturi — Aqara M1S Zigbee Router

Data auditului: **2026-08-06**  
Sursă: `de facut readme ok.zip`  
Scop: reconstruirea unei proceduri unice, complete și repetabile pentru conversia unui hub stock.

## 1. Metoda de analiză

Au fost verificate:

- toate cele 1185 fișiere din arhiva originală;
- toate cele 68 de fișiere al căror nume începe cu `README`;
- toate cele 106 fișiere Markdown, inclusiv CHANGELOG-urile;
- manifestele tuturor versiunilor integrării;
- toate cele 15 imagini firmware `.bin`;
- toate cele 13 copii ale installerului Wi-Fi `.tgz`;
- scripturile shell, serviciile Home Assistant, constantele de port, platformele și fluxurile media din v0.5.6.

Inventarul complet și gruparea după SHA256 sunt în [INVENTAR_README.md](INVENTAR_README.md).

### Compoziția arhivei originale

| Tip | Număr |
|---|---:|
| fișiere totale | 1185 |
| Python `.py` | 535 |
| JSON | 182 |
| PNG | 150 |
| bytecode `.pyc` | 144 |
| Markdown `.md` | 106 |
| YAML | 38 |
| firmware `.bin` | 15 |
| arhive `.tgz` | 13 |
| README-uri după nume | 68 |

Fișierele `.pyc` nu sunt sursă de adevăr și nu trebuie distribuite într-un release curat.

---

## 2. Concluzia principală

Arhiva nu conținea un singur „kit de instalare”, ci o cronologie de dezvoltare:

- builduri firmware distincte;
- versiuni succesive ale integrării Home Assistant;
- README-uri copiate înainte și modificate incremental;
- experimente de grup media;
- același installer Wi-Fi duplicat în 13 release-uri;
- funcții declarate în integrare fără toate scripturile necesare pe hub.

Prin urmare, simpla concatenare a README-urilor ar produce contradicții. Soluția corectă este:

1. v0.5.6 devine baza integrării curente;
2. `jn5189_router_rgb_lux_rejoin_test.bin` devine firmware-ul curent;
3. pașii de flash validați din README-urile firmware și din v0.2.1+ sunt consolidați;
4. procedura stock → Router este rescrisă în ordine tranzacțională;
5. Wi-Fi și butonul fizic sunt tratate ca module separate, explicite;
6. istoricul rămâne în audit, nu în mijlocul procedurii curente.

---

## 3. Linia versiunilor și ce a adus fiecare etapă

| Versiune | Contribuție relevantă păstrată în documentația finală |
|---|---|
| 0.1.0 | integrarea inițială, client Telnet, inel RGB, senzori de bază |
| 0.1.3 | iluminare și controale audio inițiale |
| 0.1.4 | citire directă JN5189 A6 și tunel UART 1886 |
| 0.1.5 | curățare parsing Telnet, temperatură și uptime |
| 0.1.7 | refresh țintit pentru catalogul de sunete |
| 0.1.8 | temperatură numai din proprietatea validată |
| 0.1.9 | flux de finalizare și închidere |
| 0.2.0 | media browser Home Assistant și radio nativ |
| 0.2.1 | protocol rejoin A7 și stingerea întârziată a inelului |
| 0.2.2 | upload WAV pe portul 12349 |
| 0.2.3–0.2.6 | reload controlat, etichete bilingve, administrare audio |
| 0.2.7 | stop/turn_off robust, fără `killall nc` |
| pachet 0.2.9 / manifest 0.2.7 | reluare/persistență; exemplu de nealiniere nume–manifest |
| 0.3.0–0.3.1 | două niveluri de volum și auto-resume |
| 0.3.2 | ramură experimentală, nu bază stabilă |
| 0.3.3 | watchdog reconstruit din baza 0.3.1 |
| 0.3.4–0.3.7 | diagnostic, cleanup taskuri, dispatch thread-safe, clasificarea eșecurilor |
| 0.4.0–0.4.3 | experimente pentru grup și buton; nu sunt baza release-ului final |
| 0.5.0 | reconstrucție din 0.3.7, grup cu cronologie PCM comună, event buton |
| 0.5.1 | corecții de platforme |
| 0.5.2 | pas volum 0,2% |
| 0.5.3 | resync complet la revenirea unui hub |
| 0.5.4 | debounce pentru volumul de grup |
| 0.5.5 | volum de grup live fără restart |
| 0.5.6 | gain PCM live individual, pas unic 0,1%, eliminarea Number fine-volume |

### Decizia de bază

v0.5.6 este cea mai nouă versiune cu manifest coerent și include schimbările de media cele mai avansate. Istoricul arată explicit că v0.5.0 a fost reconstruită din baza curată v0.3.7, nu continuată direct din ramurile 0.4.x.

---

## 4. Firmware-urile găsite

### Firmware curent

```text
jn5189_router_rgb_lux_rejoin_test.bin
209296 bytes
SHA256 a1a1f302be9e3ab95fd6a3b8f4ac260e1f397fec275fb3e3caf8418cd75e7a2f
```

Acesta este identic în pachetele 0.4.0–0.5.6.

### Builduri istorice relevante

| Fișier | Bytes | SHA256 | Observație |
|---|---:|---|---|
| `jn5189_router_rgb_lux.bin` | 209312 | `0c53…` | RGB + lux, documentat în README firmware inițial |
| `jn5189_router_rgb_lux_pio19.bin` | 209312 | `33fb…` | fix PIO19/ADC5, fără protocol A7 |
| `jn5189_router_rgb_lux_rejoin_test.bin` | 209296 | `a1a1…e7a2f` | build curent cu rejoin A7 |

### Problemă găsită

README-ul v0.5.6 spunea că SHA256 trebuie calculat, dar nu îl publica. Pentru o procedură repetabilă, aceasta era o gaură critică: două fișiere cu același nume nu pot fi presupuse identice. README-ul nou fixează dimensiunea și hashul exact.

---

## 5. Auditul installerului Wi-Fi

### Ce exista

Toate cele 13 fișiere `m1s_wifi_installer_from_100_BUSYBOX_V2.tgz` erau byte-identice. Installerul includea:

- `install.sh` cu backup și rollback;
- `wifi_manager.sh`;
- portalul HTTP;
- revenire STA/AP;
- multe copii `.before_*` și scripturi de test;
- patru fișiere de stare Wi-Fi deja populate:
  - `safe/ssid`;
  - `safe/pass`;
  - `previous_ssid`;
  - `previous_pass`.

Valorile nu sunt reproduse în acest audit.

### Riscul

1. Arhiva distribuia date reale de rețea.
2. Copierea pachetului pe alt hub putea suprascrie backupul Wi-Fi cu valorile vechi.
3. README-ul principal nu documenta deloc faptul că installerul era inclus.
4. Portalul folosea câmp de parolă vizibil (`type="text"`).
5. Payloadul de producție conținea istorice și teste care nu erau necesare.

### Remedierea aplicată în kitul curent

A fost creat `m1s_wifi_recovery_SANITIZED.tgz`:

- fără SSID/parolă în payload;
- `safe/ssid` și `safe/pass` sunt fișiere goale;
- installerul citește valorile curente local de pe hub înainte de orice mutație;
- se oprește fără modificări dacă nu poate citi datele curente;
- păstrează backup și rollback;
- nu loghează SSID-ul candidat;
- parola formularului este mascată;
- payloadul conține numai scripturile active;
- AP-ul automat rămâne dezactivat până la `actions_enabled`.

### Limitare rămasă

Fluxul actual cere SSID și parolă ne-goale, deci nu este documentat ca suportând rețele Wi-Fi deschise. Necesită test fizic complet după sanitizare.

---

## 6. Auditul butonului fizic

### Ce declară integrarea

v0.5.0+ creează:

- entitate event `Physical Button`;
- trigger-e `click`, `double_click`, `triple_click`, `quadruple_click`, `five_click`, `hold`;
- topic derivat din IP: `m1s/<ultimul_octet>/button/action`.

### Ce lipsea din arhivă

Nu exista scriptul persistent care:

- citește evenimentele `basis.button` ale `mha_master`;
- transformă secvențele în gestul final;
- publică MQTT către brokerul Home Assistant;
- pornește la boot.

Fără acel bridge, entitatea există în Home Assistant, dar nu primește evenimente.

### Remedierea aplicată

Kitul conține `m1s_button_bridge_SANITIZED.tgz`:

- monitorizează `/var/log/messages`, nu `/dev/input/event0`;
- filtrează `mha_master ... on_message basis.button`;
- folosește debounce 1,2 secunde pentru gestul final;
- publică MQTT 3.1.1 QoS 0 prin BusyBox `nc`;
- funcțiile de construire CONNECT/PUBLISH întorc explicit succes, inclusiv când brokerul nu cere autentificare;
- nu include IP broker, username sau parolă;
- păstrează credențialele în fișiere locale cu permisiuni 600;
- este pornit opțional de `post_init.sh`.

### Limitări rămase

- trebuie validate fizic toate cele șase gesturi;
- trebuie verificat comportamentul la rotația `/var/log/messages`;
- publisherul minimal acceptă numai pachete MQTT cu Remaining Length sub 128 bytes, suficient pentru topicul și credentialele normale documentate;
- rezervarea DHCP este obligatorie, deoarece integrarea derivă topicul din IP.

---

## 7. Auditul `post_init.sh`

### Scriptul din README v0.5.6 făcea corect

- `fw_manager.sh -r`;
- așteptare Wi-Fi;
- Telnet persistent;
- suspendare `app_monitor`;
- oprire `mzigbee_agent`;
- configurare UART;
- GPIO33=`1`, GPIO18 `1 -> 0`;
- RGB OFF după 10 secunde.

### Ce nu făcea

- nu pornea managerul/portalul Wi-Fi inclus în release;
- nu pornea bridge-ul butonului declarat de integrare;
- nu avea funcții clare de log pentru toate modulele;
- nu era livrat ca fișier separat, gata de transfer;
- documentația nu explica suficient cum se demonstrează că hookul chiar a rulat după reboot.

### Remediere

`post_init.sh` din kit păstrează comportamentul validat și adaugă pornire condiționată pentru modulele opționale. Nu pornește module inexistente și nu conține credentiale.

---

## 8. Auditul procedurii de flash

### Părți bune găsite

README-urile curente documentau:

- dezactivarea integrării Home Assistant;
- eliberarea `/dev/ttyS1`;
- GPIO pentru ISP;
- listenerul TCP–UART 1888;
- SPSDK `info`;
- backup de 646656 bytes;
- erase limitat la `0x33200`;
- write la `0x0`;
- ieșirea din ISP și boot normal;
- recuperarea după `TimeoutError`.

### Lipsuri

- backupul era citit o singură dată;
- readbackul post-write nu era parte obligatorie a fluxului curent;
- ordinea secțiunilor era `5.2` înainte de `5.1`;
- comenzile erau amestecate cu depanarea și update-uri istorice;
- nu exista un script PowerShell care să oprească automat la hash greșit;
- nu exista un checklist formal de acceptare pe etapă.

### Remediere

Procedura nouă impune:

1. două backupuri stock independente;
2. lungime identică și SHA256 identic;
3. hash fix pentru firmware;
4. `-WhatIf` înaintea operației PowerShell;
5. erase numai cu switch explicit la prima conversie;
6. readback exact de 209296 bytes;
7. comparație SHA256 sursă/readback;
8. închidere explicită a portului 1888;
9. checklist post-reboot.

---

## 9. Auditul integrării Home Assistant v0.5.6

### Platforme încărcate

```text
button
event
light
media_player
number
sensor
switch
```

`select.py` există, dar nu este încărcat. Este cod legacy și nu trebuie prezentat ca funcție curentă.

### Dependențe manifest

```text
file_upload
mqtt
```

Nu există requirements Python externe în manifest.

### Servicii

```text
play_url
play_sound
run_command
upload_sound
delete_sound
refresh_sounds
```

### Observații importante

1. **Config flow fără probă reală de conexiune** — datele sunt salvate fără un test complet Telnet; documentația cere verificare manuală înainte.
2. **`run_command` este administrativ** — permite shell arbitrar pe hub.
3. **`mqtt_client.py` este legacy/nefolosit** — descrie portul 1884, dar nu este importat de fluxul curent.
4. **`select.py` este legacy** — platforma nu este forwardată.
5. **Conflict port 12347** — `media_group.py` folosește 12347, iar `sound_player.py` folosește tot 12347 ca sursă WAV. README-ul vechi nu evidenția conflictul.
6. **Prioritatea individuală față de grup** este implementată, dar nu rezolvă automat conflictul WAV local–grup.
7. **Entități vechi** — v0.5.6 șterge din registry Number-urile de volum fin.

### Porturi extrase din cod

| Port | Cod | Rol |
|---:|---|---|
| 23 | `const.py` | Telnet implicit |
| 1884 | `mqtt_client.py` | legacy/nefolosit |
| 1886 | `client.py` | UART JN5189 |
| 12346 | `media_player.py` | player individual |
| 12347 | `media_group.py` | grup media |
| 12347 | `sound_player.py` | sursă WAV locală — conflict |
| 12348 | `sound_player.py` | sink PCM WAV |
| 12349 | `client.py` | upload WAV |

Porturile 1888, 1889, 8080 și 12345 aparțin procedurilor/modulelor de hub, nu manifestului integrării.

---

## 10. Probleme editoriale în README v0.5.6

- titlul „Entități în v0.5.0” era rămas într-un release 0.5.6;
- secțiunea v0.2.6 ocupa spațiu principal în loc să fie în istoric;
- finalul conținea încă „Actualizare de la v0.2.0”;
- v0.5.4 și v0.5.5 erau prezentate la final ca extensii, deși v0.5.6 le include;
- buildul experimental fără switch apărea înaintea procedurii principale și putea fi confundat cu firmware curent;
- Wi-Fi installerul inclus nu era menționat;
- butonul era descris ca funcție completă fără bridge-ul hub-side;
- hashul firmware-ului curent lipsea;
- nu exista matrice clară „obligatoriu vs opțional”; 
- nu exista listă de secrete care trebuie excluse din release.

README-ul nou mută experimentele și istoricul în audit și păstrează un singur „golden path”.

---

## 11. Matricea etapelor și sursa adevărului

| Etapă | Sursa principală folosită | Decizie finală |
|---|---|---|
| model/hardware | README firmware + toate README-urile integrare | numai `lumi.gateway.aeu01` |
| token/Telnet | README 0.2.x–0.5.6 | păstrat, cu avertizare secret |
| boot persistent | README 0.4.x–0.5.6 | păstrat și modularizat |
| backup JN5189 | README firmware + v0.2.1+ | două citiri identice |
| ISP 1888 | README v0.5.x | script separat, listener în buclă |
| erase/write | README v0.5.6 + README firmware PIO19 | erase numai `0x33200`, write `0x0` |
| verificare post-write | README mai vechi + bune practici din proiect | readback obligatoriu |
| Zigbee Router | README firmware + integrare | Permit join înainte de boot |
| RGB/lux/A7 | README firmware și client.py | protocoale documentate exact |
| HA v0.5.6 | manifest și cod curent | v0.5.6 este baza |
| media | media_player.py/media_group.py/sound_player.py | funcții + conflict 12347 documentat |
| buton | event.py/device_trigger.py/const.py + contextul proiectului | pachet hub-side separat |
| Wi-Fi | installer duplicat și scripturile active | pachet sanitizat separat |
| recuperare | secțiunile TimeoutError și backup | pași separați, fără erase reflex |

---

## 12. Fișiere excluse din release-ul curat

- `.pyc`;
- `__pycache__`;
- fișiere `*.before_*` ale experimentelor Wi-Fi;
- `previous_ssid` și `previous_pass`;
- orice `safe/ssid` sau `safe/pass` populat;
- loguri de analiză;
- tokenuri MiIO;
- credentiale MQTT;
- backupuri flash stock;
- copii redundante ale installerului vechi.

Arhiva istorică sanitizată păstrează structura versiunilor, dar golește credentialele din toate cele 13 installere. Kitul curent păstrează numai pachetul Wi-Fi nou.

---

## 13. Verificări executate asupra kitului

- sintaxă `/bin/sh -n` pentru toate scripturile hub și installere;
- compilare Python a integrării v0.5.6;
- parsare JSON pentru manifest, strings și translations;
- verificare structură pentru toate arhivele `.tgz` create;
- verificare la nivel de bytes a pachetului MQTT 3.1.1 generat de bridge-ul butonului;
- test sintetic al mapării acțiunilor și al debounce-ului bridge-ului de buton;
- verificare dimensiune și SHA256 firmware;
- scanare după valorile Wi-Fi originale în fișierele text și configurațiile outputurilor finale;
- verificare că fișierele de credentiale din payload au zero bytes;
- inventar SHA256 al livrabilelor.

PowerShell nu este disponibil în mediul de analiză, deci scripturile `.ps1` au fost inspectate structural, dar nu executate într-un motor PowerShell. Aceasta este notată ca limitare de validare, nu ascunsă.

---

## 14. Ce urmează în introspecția separată

README-ul este acum pregătit să servească drept specificație. Introspecția de cod ulterioară trebuie să verifice implementarea față de această specificație, cu prioritate pentru:

1. conflictul 12347;
2. arbitrajul complet individual/grup/WAV;
3. task cleanup și reconnect în toate ramurile;
4. config flow cu validare reală;
5. eliminarea modulelor legacy;
6. suprafața de atac `run_command`;
7. testele unitare pentru gain S32_LE și rampă;
8. testele fizice pentru buton și Wi-Fi recovery;
9. alinierea README/manifest/tag/release.

---

## 15. Verdict

Arhiva veche conținea suficientă informație tehnică pentru refacerea proiectului, dar nu era încă un pachet reproductibil pentru un utilizator nou. Principalele cauze erau amestecarea istoricului cu prezentul, lipsa hashului firmware curent, lipsa bridge-ului butonului și credențialele Wi-Fi incluse în pachete duplicate.

Kitul rezultat oferă acum:

- o singură procedură actuală;
- scripturi gata de transfer;
- verificări și puncte de oprire;
- module opționale separate;
- secrete eliminate;
- limitări declarate;
- trasabilitate către toate README-urile analizate.

---

## Addendum 2026-08-07 — comparație cu README-ul GitHub

Snapshotul GitHub furnizat ulterior auditului inițial a fost comparat integral cu README-ul master și cu fișierele reale din kit. Constatările care schimbă procedura pentru un hub stock au fost integrate în revizia R2:

- alegerea stock STA/AP pe baza `cloud_provisioned`, `hap_provisioned` și `hap_keepalive`;
- scriptul nou `aqara_wifi_boot_state.sh check|fix`, fără acces la SSID/parolă;
- interdicția explicită a `fw_manager.sh -f -r` în bootul persistent;
- fluxul complet de administrare și download WAV;
- disponibilitatea la 15 secunde și RGB OFF la revenire;
- traseul HACS și rejoin;
- marcarea buildului experimental `no_switch` ca nerecomandat.

Detaliile de triere sunt în `COMPARATIE_README_GITHUB_2026-08-07.md`. Valorile concrete ale huburilor și pașii istorici v0.2.x–v0.5.5 nu au fost transformați în instrucțiuni curente.
