# Comparație cu README-ul GitHub — 2026-08-07

Document comparat: snapshotul README furnizat de utilizator, 1106 linii.
Scop: verificarea completitudinii ghidului master pentru conversia unui hub stock, fără a amesteca istoricul sau experimentele cu procedura curentă.

## 1. Elemente noi integrate în README_RO.md

| Element din snapshotul GitHub | Acțiune în revizia R2 |
|---|---|
| Firmware-ul stock poate alege AP când `cloud_provisioned`, `hap_provisioned` și `hap_keepalive` sunt toate inactive | Integrat ca etapa 9A, înainte de instalarea bootului persistent |
| `user_paired=true`, SSID-ul/parola salvate și backupul local Wi-Fi nu influențează această alegere | Explicat explicit, fără afișarea credentialelor |
| Corecția prin `setprop ... true` | Transformată într-un script reutilizabil: `scripts/hub/aqara_wifi_boot_state.sh check|fix` |
| Diferența dintre `fw_manager.sh -r` și `fw_manager.sh -f -r` | Marcată critic: `-r` este boot normal, `-f -r` nu se folosește în `post_init.sh` |
| Integrarea Home Assistant poate recrea `cat /dev/ttyS1` și bloca SPSDK | Era deja documentat; a fost păstrat în preflight și recuperarea `TimeoutError` |
| Listenerul BusyBox `nc` este one-shot | Era deja rezolvat prin bucla persistentă din scriptul ISP; explicația a fost păstrată |
| UI-ul pentru rejoin și necesitatea Permit join | Completat cu traseul exact din Home Assistant și nota despre intrarea stale pe coordonatorul vechi |
| HACS instalează direct repository-ul | Adăugat; pentru reproducibilitate se cere release-ul 0.5.6 și verificarea manifestului |
| Disponibilitatea la 15 secunde și RGB OFF după 10 secunde la revenire | Adăugat la secțiunea entităților |
| Playerul nativ, BROWSE_MEDIA, URL-uri și Radio Favorites | Completat în secțiunea audio; Radio Favorites rămâne opțional |
| `nice -5` pentru FFmpeg și `nice -3` pentru `aplay` | Adăugat, cu precizarea că sunt priorități Linux normale, best-effort |
| Fluxul complet Upload/Delete/Finish pentru WAV | Integrat, inclusiv refresh imediat, reload final și comportamentul butonului X |
| Download WAV prin portul 1889 | Integrat folosind scriptul existent `Receive-FileFromM1S.ps1` |
| Verificarea dimensiunii și integrității uploadului, fallback base64 | Adăugat conform implementării reale v0.5.6 |
| Buildul experimental `no_switch` nu a eliminat switch-ul | Marcat explicit ca nerecomandat; problema a fost păstrată pentru introspecția de cod |

## 2. Elemente deja acoperite de kitul anterior

- adăugarea în Xiaomi Home și diferența față de secvența Telnet;
- tokenul MiIO de 32 caractere hexazecimale și verificarea lui;
- Telnet temporar și persistent;
- identificarea modelului, Linuxului, BusyBox și UART-ului;
- dezactivarea temporară a integrării Home Assistant înainte de ISP;
- suspendarea `app_monitor`, oprirea `mzigbee_agent` și eliberarea `/dev/ttyS1`;
- listenerul TCP-UART pe portul 1888;
- două backupuri stock identice și SHA256;
- geometria FLASH JN5189, erase limitat și interdicția EFUSE/ROM/Config/PSECT/pFLASH;
- write, readback și comparație SHA256;
- ieșirea din ISP și bootul Router;
- protocoalele A5 RGB, A6 lux și A7 rejoin;
- instalarea HACS/manuală a integrării;
- entitățile, playerul individual, grupul media și bridge-ul butonului;
- porturile, fișierele persistente, securitatea și procedurile de recuperare.

## 3. Elemente păstrate numai ca istoric, nu în traseul principal

- valorile concrete ale huburilor `.100`, `.101`, `.102` și `.104`;
- secțiunile de upgrade de la v0.2.0;
- comportamentul intermediar al volumului din v0.5.4 și v0.5.5;
- instrucțiunile specifice buildurilor vechi PIO19 fără A7;
- detaliile buildului experimental `jn5189_router_rgb_lux_no_switch.bin`;
- formulări care numesc v0.5.0 drept versiune curentă, deși release-ul folosit este 0.5.6.

Aceste informații sunt utile pentru trasabilitate, dar ar crea ambiguitate pentru cineva care face conversia prima dată.

## 4. Corecții de structură față de snapshot

- cauza AP stock este mutată înainte de primul reboot, nu lăsată ca anexă la începutul unui README în engleză;
- numerotarea `5.2` înainte de `5.1` nu este preluată;
- comenzile destructive sunt precedate de criterii de oprire și de verificare;
- procedura recomandată folosește scripturile kitului, nu blocuri lungi copiate manual;
- nu sunt incluse SSID-uri, parole Wi-Fi, tokenuri MiIO, credentiale MQTT sau valori concrete de rețea;
- procedura curentă este separată de istoricul integrării și de experimentele firmware.

## 5. Fișiere modificate în revizia R2

- `README_RO.md`;
- `scripts/hub/aqara_wifi_boot_state.sh` — nou;
- `scripts/hub/post_init.sh` — avertisment non-secret pentru risc AP și precizarea bootului normal;
- `scripts/hub/jn5189_preflight.sh` — afișează stările STA/AP fără credențiale;
- `scripts/hub/verify_hub.sh` — verifică stările după reboot;
- `docs/VALIDATION_REPORT.md`;
- `SHA256SUMS.txt`.

## 6. Verdict

Snapshotul GitHub conținea completări reale și utile, în special explicația pornirii stock în AP și fluxul complet de administrare WAV. După integrarea selectivă, README-ul master R2 acoperă aceste puncte fără să transforme experimentele și istoricul în pași recomandați pentru conversia unui hub nou.
