# Raport de validare — Aqara M1S Complete Kit v0.5.6

Data validării: **2026-08-07**  
Tip validare: **audit documentar + verificare statică + teste comportamentale izolate**

## 1. Domeniul verificat

Au fost analizate toate materialele din arhiva de lucru, nu doar modulul Wi-Fi:

- **1185 fișiere** în arhiva originală;
- **68 fișiere README**;
- **38 fișiere CHANGELOG**;
- **106 documente README/CHANGELOG** în total;
- **86 conținuturi unice** după deduplicare SHA256;
- snapshotul README GitHub furnizat la 2026-08-07, cu 1106 linii;
- versiunile integrării de la 0.1.x până la 0.5.6;
- toate firmware-urile JN5189 găsite;
- scripturile de boot, UART/ISP, backup, flash, audio, buton și recuperare Wi-Fi;
- integrarea Home Assistant v0.5.6 și manifestul ei;
- arhivele `.tgz` incluse în release;
- arhiva istorică sanitizată.

Procedura curentă a fost separată de materialele istorice. Sursa principală pentru o conversie nouă este `README_RO.md`; documentele originale sunt păstrate numai pentru trasabilitate.

## 2. Baza curentă confirmată

| Element | Valoare validată |
|---|---|
| Integrare Home Assistant | `0.5.6` |
| Model țintă | `lumi.gateway.aeu01` |
| Firmware curent | `jn5189_router_rgb_lux_rejoin_test.bin` |
| Dimensiune firmware | `209296` bytes |
| SHA256 firmware | `a1a1f302be9e3ab95fd6a3b8f4ac260e1f397fec275fb3e3caf8418cd75e7a2f` |
| Zonă erase aplicație | `0x33200` |
| FLASH Memory ID | `0` |
| Backup stock așteptat | `646656` bytes (`0x9DE00`) |

## 3. Verificări statice executate

Toate verificările de mai jos au trecut:

- existența fișierelor obligatorii ale kitului;
- dimensiunea și SHA256 firmware;
- parsarea celor 5 fișiere JSON;
- compilarea tuturor modulelor Python ale integrării;
- eliminarea completă a fișierelor `.pyc` și a folderelor `__pycache__` din release;
- `/bin/sh -n` pentru cele 10 scripturi shell vizibile direct;
- integritatea celor 4 arhive `.tgz` din kit;
- `/bin/sh -n` pentru cele 13 scripturi shell din payloadurile arhivelor;
- protecție împotriva căilor absolute sau `..` în arhivele tar;
- rezolvarea tuturor linkurilor Markdown relative;
- verificare structurală pentru cele 5 scripturi PowerShell;
- test CRC complet pentru arhiva istorică sanitizată;
- confirmarea celor 13 copii istorice ale installerului Wi-Fi sanitizat;
- verificarea reviziei R2: 60 fișiere în kit, 9 documente Markdown, 10 scripturi shell directe, 13 scripturi shell unice în arhive, 18 module Python și 5 fișiere JSON;
- zero containere sensibile populate și zero credentiale hardcodate detectate în fișierele text/configurație ale release-ului.

## 4. Teste comportamentale izolate

### Publisher MQTT al butonului

Publisherul BusyBox a fost executat cu un `nc` controlat, care a capturat pachetul binar și a răspuns cu un CONNACK valid. Au fost validate:

- antetul CONNECT MQTT 3.1.1;
- protocolul `MQTT`, nivel 4;
- topicul `m1s/104/button/action`;
- payloadul `triple_click`;
- pachetul DISCONNECT;
- acceptarea brokerului fără username și parolă.

Rezultat: `MQTT_PACKET_OK`, pachet de 63 bytes.

În timpul acestui test a fost găsită și corectată o eroare: `build_connect()` întorcea cod 1 când autentificarea MQTT era goală, deoarece ultima expresie condițională era falsă. Funcțiile CONNECT și PUBLISH întorc acum explicit succes după construirea corectă a pachetului.

### Watcher și debounce pentru buton

Watcherul a fost alimentat cu linii sintetice de log, în aceeași formă filtrată din `/var/log/messages`. Secvența testată a confirmat:

- `click` urmat rapid de `double_click` produce numai `double_click`;
- `persist_click=3` produce `triple_click` după fereastra de debounce;
- `hold` anulează gesturile în așteptare și este publicat imediat.

Rezultat: `BUTTON_DEBOUNCE_OK` cu acțiunile finale `double_click`, `triple_click`, `hold`.

### Starea stock STA/AP

Noul script `aqara_wifi_boot_state.sh` a fost executat cu implementări controlate pentru `getprop` și `setprop`:

- cu toate proprietățile goale, `check` a returnat cod 1 și `BOOT_WIFI_SELECTION=AP_RISK`;
- `fix` a setat numai cele patru proprietăți documentate;
- verificarea ulterioară a returnat cod 0 și `BOOT_WIFI_SELECTION=STA_EXPECTED`;
- scriptul nu citește și nu afișează SSID-ul, parola Wi-Fi sau tokenul MiIO.

Rezultat: `WIFI_BOOT_STATE_BEHAVIOR_OK`.

## 5. Eliminarea SSID-urilor și parolelor

În arhiva originală existau **13 copii identice** ale installerului Wi-Fi. Fiecare transporta fișiere de stare populate:

- `safe/ssid`;
- `safe/pass`;
- `previous_ssid`;
- `previous_pass`.

Remedierea verificată:

- toate cele 13 installere din arhiva istorică au fost înlocuite cu varianta sanitizată;
- `safe/ssid` și `safe/pass` există în payload doar ca fișiere de zero bytes;
- `previous_ssid` și `previous_pass` nu mai există;
- installerul preia valorile curente numai local, de pe hub, înainte de a modifica instalarea;
- pagina portalului folosește câmp HTML de tip `password`;
- fișierele MQTT `mqtt_username` și `mqtt_password` sunt tot de zero bytes;
- valorile Wi-Fi originale identificate au fost căutate fără a fi afișate;
- nu există apariții ale acelor valori în fișierele text/configurație ale kitului final;
- nu există apariții ale acelor valori în fișierele text/configurație ale arhivei istorice sanitizate.

Scanarea este orientată corect pe fișiere de text, configurație și containere de credențiale. Nu se interpretează potriviri întâmplătoare de bytes din firmware ca expuneri de parolă.

## 6. Ce nu a fost declarat fals ca „validat”

Următoarele necesită încă test fizic pe un hub real:

- intrarea efectivă în ISP prin GPIO18/GPIO33;
- două backupuri stock identice prin SPSDK;
- flash, readback și reboot complet;
- rejoin Zigbee și comportamentul după întrerupere de curent;
- toate cele șase gesturi ale butonului fizic;
- rotația reală a `/var/log/messages`;
- recuperarea Wi-Fi, rollbackul și portalul AP;
- audio individual, grup și WAV local în toate combinațiile.

Motorul PowerShell nu este instalat în mediul de audit. Scripturile `.ps1` au fost verificate structural, dar trebuie rulate întâi cu `-WhatIf` și apoi pe hubul de test conform README-ului.

## 7. Probleme cunoscute păstrate pentru introspecția de cod

Documentația nu ascunde problemele din implementarea v0.5.6:

1. portul `12347` este folosit atât de playerul de grup, cât și de sursa WAV locală;
2. `mqtt_client.py` și `select.py` par ramuri legacy/neîncărcate;
3. config flow nu validează conexiunea reală înainte de salvare;
4. serviciul `run_command` expune o suprafață de comandă shell foarte largă;
5. cleanup/reconnect și arbitrajul media trebuie urmărite în toate ramurile asincrone;
6. recuperarea Wi-Fi actuală cere SSID și parolă ne-goale, deci rețelele deschise nu sunt acoperite.

Acestea sunt marcate pentru introspecția următoare și nu sunt confundate cu erori de documentare.

## 8. Revizia documentară R2

README-ul GitHub din 2026-08-07 a fost comparat cu ghidul master și cu implementarea reală v0.5.6. Au fost integrate selectiv:

- logica stock STA/AP și diferența față de managerul Wi-Fi opțional;
- avertismentul `fw_manager.sh -r` versus `fw_manager.sh -f -r`;
- traseul exact pentru rejoin și instalarea HACS;
- comportamentul de disponibilitate și RGB OFF la revenire;
- browse media, prioritățile best-effort și fluxul complet WAV;
- excluderea explicită a buildului experimental `no_switch`.

Valorile concrete ale huburilor, upgrade-urile vechi și comportamentele intermediare v0.5.4/v0.5.5 nu au fost introduse în traseul de instalare nouă. Vezi `COMPARATIE_README_GITHUB_2026-08-07.md`.

## 9. Verdict

Kitul este coerent ca **release documentat și sanitizat** și oferă un singur traseu reproductibil pentru cineva care începe cu un hub stock. Scripturile, arhivele, hashurile, legăturile și pachetele opționale au trecut verificările statice și testele izolate descrise mai sus.

Nu trebuie numit încă „validat complet pe hardware” până când checklistul fizic din `README_RO.md` nu este executat integral pe un hub de test și rezultatele nu sunt păstrate în jurnalul de conversie.


## Addendum v0.5.7 — Wi-Fi from Configure

Static validation was repeated after adding the Home Assistant Wi-Fi change flow. The form does not persist the Wi-Fi password; the client stages credentials only on the hub and starts the existing recovery helper. The helper was hardened to clear a stale IPv4 before candidate validation. This path still requires one physical end-to-end validation on a real hub before being called hardware-validated.
